"""
Gerador de sprites em pixel art (originais) para o RPG de turnos.

Rode:  python gerar_sprites.py
Gera:
  sprites/gif/<classe>_<sexo>_<animacao>.gif      (GIFs animados, para ver/usar)
  sprites/frames/<classe>_<sexo>/<anim>_<n>.png   (frames usados pelo jogo)
  sprites/frames/duracoes.json                    (tempo de cada frame em ms)

Classes: guerreiro, mago, sacerdote, arqueiro   |   Sexos: masculino, feminino
Precisa de:  pip install pillow
"""
import json
import math
import os

from PIL import Image, ImageDraw, ImageFilter

LW, LH = 92, 64          # tamanho "lógico" (em pixels de pixel art)
ESC_GIF = 4              # zoom dos GIFs
ESC_JOGO = 2             # zoom dos PNGs usados no jogo
OX, OY = 22, 56          # posição dos pés do personagem
PASTA = "sprites"


def hexa(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5)) + (255,)


P = {
    "pele": hexa("#f0be96"), "pele_s": hexa("#c98f68"),
    "contorno": hexa("#1c1a2b"),
    "aco": hexa("#a9b4c4"), "aco_s": hexa("#6b778c"), "aco_c": hexa("#e4ebf5"),
    "creme": hexa("#efe9d2"), "creme_s": hexa("#c9bf9c"),
    "marrom": hexa("#7a4a24"), "marrom_s": hexa("#4f2f16"),
    "ouro": hexa("#e0b040"), "ouro_s": hexa("#a47a1e"),
    "verde": hexa("#3f8f5a"), "verde_s": hexa("#2c6a42"),
    "cabelo_m": hexa("#6e3b1c"), "cabelo_f": hexa("#c85a28"),
    "cabelo_c": hexa("#7a4426"), "cabelo_c_s": hexa("#5a3019"),
    "azul": hexa("#3c4a9a"), "azul_s": hexa("#2a336f"),
    "cinza": hexa("#7c7f8f"), "cinza_s": hexa("#585a69"),
    "roxo": hexa("#6b3fa0"), "roxo_s": hexa("#4b2a75"),
    "branco": hexa("#f4f4fb"), "barba": hexa("#e8e8ee"),
    "olho": hexa("#1c1a2b"),
    "vermelho": hexa("#d8382a"), "laranja": hexa("#ff8c1e"),
    "amarelo": hexa("#ffe45a"), "ciano": hexa("#5ad8ff"),
    "azul_c": hexa("#9ae8ff"), "verde_c": hexa("#8dffa8"),
    "frasco": hexa("#4aa8ff"), "cortica": hexa("#a8742e"),
    "oliva": hexa("#5c8a3a"), "oliva_s": hexa("#3d5e26"),
}


# ---------------------------------------------------------------
# Primitivas de desenho
# ---------------------------------------------------------------
def r(v):
    return int(round(v))


def pt(d, x, y, c):
    d.point((r(x), r(y)), fill=c)


def ret(d, x0, y0, x1, y1, c):
    d.rectangle([r(x0), r(y0), r(x1), r(y1)], fill=c)


def lin(d, a, b, c, w=1):
    d.line([(r(a[0]), r(a[1])), (r(b[0]), r(b[1]))], fill=c, width=w)


def disco(d, x, y, raio, c):
    d.ellipse([r(x - raio), r(y - raio), r(x + raio), r(y + raio)], fill=c)


def poli(d, pts, c):
    d.polygon([(r(x), r(y)) for x, y in pts], fill=c)


def vec(ang):
    a = math.radians(ang)
    return math.cos(a), -math.sin(a)


def estrela(d, x, y, c, tam=1):
    pt(d, x, y, c)
    for k in range(1, tam + 1):
        pt(d, x + k, y, c)
        pt(d, x - k, y, c)
        pt(d, x, y + k, c)
        pt(d, x, y - k, c)


def ponta_arma(ox, oy, mao, ang, comp):
    dx, dy = vec(ang)
    return ox + mao[0] + dx * comp, oy + mao[1] + dy * comp


# ---------------------------------------------------------------
# Personagens
# ---------------------------------------------------------------
def desenhar_arma(d, tipo, p0, ang, comp, orbe=None):
    dx, dy = vec(ang)
    gx, gy = -dy, dx
    if tipo == "espada":
        base = (p0[0] + dx * 2, p0[1] + dy * 2)
        ponta = (p0[0] + dx * comp, p0[1] + dy * comp)
        lin(d, (p0[0] - dx * 3, p0[1] - dy * 3), p0, P["marrom"], 2)
        lin(d, base, ponta, P["aco_c"], 2)
        lin(d, (base[0] - gx * 3, base[1] - gy * 3),
            (base[0] + gx * 3, base[1] + gy * 3), P["ouro"], 2)
    elif tipo == "arco":
        tensao, flecha = orbe if orbe else (0, False)
        h = comp / 2
        pts = [(p0[0] + gx * t * h - dx * t * t * 3, p0[1] + gy * t * h - dy * t * t * 3)
               for t in (-1, -0.5, 0, 0.5, 1)]
        for a, b in zip(pts, pts[1:]):
            lin(d, a, b, P["marrom"], 2)
        pt(d, p0[0], p0[1], P["ouro_s"])
        pt(d, p0[0] - gx, p0[1] - gy, P["ouro_s"])
        nock = (p0[0] - dx * (3 + 9 * tensao), p0[1] - dy * (3 + 9 * tensao))
        lin(d, pts[0], nock, P["branco"], 1)
        lin(d, pts[-1], nock, P["branco"], 1)
        if flecha:
            ponta = (nock[0] + dx * 17, nock[1] + dy * 17)
            lin(d, nock, ponta, P["creme"], 1)
            poli(d, [(ponta[0] + dx * 2, ponta[1] + dy * 2),
                     (ponta[0] - dx * 2 + gx * 1.5, ponta[1] - dy * 2 + gy * 1.5),
                     (ponta[0] - dx * 2 - gx * 1.5, ponta[1] - dy * 2 - gy * 1.5)], P["aco_c"])
            pt(d, nock[0] + gx, nock[1] + gy, P["vermelho"])
            pt(d, nock[0] - gx, nock[1] - gy, P["vermelho"])
        if flecha or tensao > 0:
            ret(d, nock[0] - 1, nock[1] - 1, nock[0], nock[1], P["pele"])      # mão que puxa a corda
    elif tipo in ("cajado", "maca"):
        ini = (p0[0] - dx * 8, p0[1] - dy * 8)
        fim = (p0[0] + dx * comp, p0[1] + dy * comp)
        lin(d, ini, fim, P["marrom"], 2)
        lin(d, ini, (ini[0] + dx * 2, ini[1] + dy * 2), P["marrom_s"], 2)
        if tipo == "cajado":
            cor, raio = orbe if orbe else (P["ciano"], 2)
            disco(d, fim[0], fim[1], raio, cor)
            pt(d, fim[0] - 1, fim[1] - 1, P["branco"])
            # "garra" de apoio da orbe
            lin(d, (fim[0] - dx * 3 - gx * 2, fim[1] - dy * 3 - gy * 2),
                (fim[0] - dx * 3 + gx * 2, fim[1] - dy * 3 + gy * 2),
                P["marrom_s"], 1)
        else:
            cor, raio = orbe if orbe else (P["ouro"], 2)
            ret(d, fim[0] - 1, fim[1] - 4, fim[0], fim[1] + 3, P["ouro"])
            ret(d, fim[0] - 3, fim[1] - 2, fim[0] + 2, fim[1] - 1, P["ouro"])
            pt(d, fim[0] - 1, fim[1] - 2, P["ciano"])


def desenhar_escudo(d, x, y, grande=False):
    rx, ry = (5, 8) if grande else (4, 6)
    d.ellipse([r(x - rx), r(y - ry), r(x + rx), r(y + ry)], fill=P["aco_s"])
    d.ellipse([r(x - rx + 1), r(y - ry + 1), r(x + rx - 1), r(y + ry - 1)], fill=P["aco"])
    ret(d, x - 1, y - ry + 2, x, y + ry - 2, P["ouro"])
    ret(d, x - rx + 2, y - 1, x + rx - 3, y, P["ouro"])
    pt(d, x - rx + 2, y - ry + 3, P["aco_c"])


def desenhar_frasco(d, x, y, inclina=0):
    ret(d, x - 1, y - 2, x + 1, y + 2, P["frasco"])
    pt(d, x - 1, y - 2, P["azul_c"])
    ret(d, x, y - 4, x, y - 3, P["branco"])
    pt(d, x, y - 5, P["cortica"])
    if inclina:
        pt(d, x + 2, y - 3, P["azul_c"])


def desenhar_personagem(d, cls, sexo, pose):
    ox = OX + pose.get("dx", 0)
    oy = OY + pose.get("dy", 0)
    ag = pose.get("ag", 0)
    fem = sexo == "feminino"
    topo = oy - 31 + ag                      # topo da cabeça
    mao = (ox + pose["mao"][0], oy + pose["mao"][1])
    mao2 = (ox + pose.get("mao2", (-7, -13))[0], oy + pose.get("mao2", (-7, -13))[1])
    ombro_f = (ox + 4, oy - 20 + ag)
    ombro_t = (ox - 5, oy - 20 + ag)

    manga = {"guerreiro": P["aco"], "mago": P["azul"], "sacerdote": P["creme"], "arqueiro": P["oliva"]}[cls]
    if cls == "mago":
        manga = P["roxo"] if fem else P["cinza"]
    if cls == "sacerdote":
        manga = P["creme"]

    # braço de trás
    lin(d, ombro_t, mao2, manga, 3)
    ret(d, mao2[0] - 1, mao2[1] - 1, mao2[0], mao2[1], P["pele"])

    # ---- pernas / base
    if cls == "guerreiro":
        ret(d, ox - 4, oy - 11 + ag, ox - 1, oy, P["aco_s"])
        ret(d, ox + 1, oy - 11 + ag, ox + 4, oy, P["aco_s"])
        ret(d, ox - 4, oy - 4, ox - 1, oy, P["aco"])
        ret(d, ox + 1, oy - 4, ox + 4, oy, P["aco"])
        ret(d, ox + 1, oy - 1, ox + 6, oy, P["aco"])
        ret(d, ox - 4, oy - 1, ox + 0, oy, P["aco"])
    elif cls == "arqueiro":
        ret(d, ox - 4, oy - 11 + ag, ox - 1, oy, P["marrom"])
        ret(d, ox + 1, oy - 11 + ag, ox + 4, oy, P["marrom"])
        ret(d, ox - 4, oy - 4, ox - 1, oy, P["marrom_s"])
        ret(d, ox + 1, oy - 4, ox + 4, oy, P["marrom_s"])
        ret(d, ox + 1, oy - 1, ox + 6, oy, P["marrom_s"])
        ret(d, ox - 4, oy - 1, ox + 0, oy, P["marrom_s"])
    else:
        cor_r = {"mago": (P["roxo"], P["roxo_s"]) if fem else (P["cinza"], P["cinza_s"]),
                 "sacerdote": (P["creme"], P["creme_s"])}[cls]
        poli(d, [(ox - 5, oy - 12 + ag), (ox + 4, oy - 12 + ag), (ox + 7, oy - 2), (ox - 8, oy - 2)], cor_r[0])
        ret(d, ox - 8, oy - 3, ox - 6, oy - 2, cor_r[1])
        ret(d, ox - 3, oy - 2, ox + 0, oy, P["marrom_s"])
        ret(d, ox + 2, oy - 2, ox + 6, oy, P["marrom_s"])

    # ---- tronco
    if cls == "guerreiro":
        ret(d, ox - 5, oy - 22 + ag, ox + 4, oy - 11 + ag, P["creme"])
        ret(d, ox - 5, oy - 22 + ag, ox - 4, oy - 11 + ag, P["creme_s"])
        ret(d, ox - 5, oy - 14 + ag, ox + 4, oy - 13 + ag, P["marrom"])           # cinto
        pt(d, ox, oy - 14 + ag, P["ouro"])
        lin(d, (ox - 4, oy - 22 + ag), (ox + 3, oy - 14 + ag), P["marrom_s"], 1)  # tira
        saia = (ox - 6, ox + 5) if fem else (ox - 5, ox + 4)
        ret(d, saia[0], oy - 12 + ag, saia[1], oy - 7 + ag, P["creme"])
        ret(d, saia[0], oy - 12 + ag, saia[0] + 1, oy - 7 + ag, P["creme_s"])
        ret(d, ox + 2, oy - 23 + ag, ox + 6, oy - 20 + ag, P["aco"])             # ombreira
        ret(d, ox - 7, oy - 23 + ag, ox - 3, oy - 20 + ag, P["aco_s"])
        pt(d, ox + 3, oy - 23 + ag, P["aco_c"])
    elif cls == "mago":
        cor, sombra = (P["roxo"], P["roxo_s"]) if fem else (P["cinza"], P["cinza_s"])
        ret(d, ox - 5, oy - 22 + ag, ox + 4, oy - 12 + ag, cor)
        ret(d, ox - 5, oy - 22 + ag, ox - 4, oy - 12 + ag, sombra)
        ret(d, ox - 5, oy - 15 + ag, ox + 4, oy - 14 + ag, P["laranja"] if fem else P["ouro"])
        pt(d, ox, oy - 15 + ag, P["amarelo"])
        ret(d, ox - 1, oy - 22 + ag, ox + 1, oy - 21 + ag, P["laranja"] if fem else P["ouro"])
    elif cls == "arqueiro":
        ret(d, ox - 8, oy - 26 + ag, ox - 5, oy - 13 + ag, P["marrom"])            # aljava nas costas
        ret(d, ox - 8, oy - 26 + ag, ox - 8, oy - 13 + ag, P["marrom_s"])
        pt(d, ox - 7, oy - 28 + ag, P["vermelho"]); pt(d, ox - 6, oy - 29 + ag, P["branco"])
        pt(d, ox - 5, oy - 28 + ag, P["vermelho"])
        ret(d, ox - 5, oy - 22 + ag, ox + 4, oy - 11 + ag, P["oliva"])
        ret(d, ox - 5, oy - 22 + ag, ox - 4, oy - 11 + ag, P["oliva_s"])
        saia = (ox - 6, ox + 5) if fem else (ox - 5, ox + 4)
        ret(d, saia[0], oy - 12 + ag, saia[1], oy - 8 + ag, P["oliva"])
        ret(d, saia[0], oy - 12 + ag, saia[0] + 1, oy - 8 + ag, P["oliva_s"])
        ret(d, ox - 5, oy - 14 + ag, ox + 4, oy - 13 + ag, P["marrom"])           # cinto
        pt(d, ox, oy - 14 + ag, P["ouro"])
        lin(d, (ox - 4, oy - 22 + ag), (ox + 3, oy - 14 + ag), P["marrom_s"], 1)  # tira da aljava
    else:  # sacerdote
        ret(d, ox - 5, oy - 22 + ag, ox + 4, oy - 12 + ag, P["creme"])
        ret(d, ox - 1, oy - 22 + ag, ox + 0, oy - 3, P["ouro"])                   # faixa dourada
        ret(d, ox - 6, oy - 23 + ag, ox - 3, oy - 10 + ag, P["verde"])           # capa atrás
        ret(d, ox - 6, oy - 23 + ag, ox + 5, oy - 21 + ag, P["verde"])           # gola verde
        ret(d, ox - 5, oy - 14 + ag, ox + 4, oy - 13 + ag, P["marrom"])

    # ---- cabeça
    ret(d, ox - 3, topo + 1, ox + 3, topo + 8, P["pele"])
    ret(d, ox - 3, topo + 6, ox - 3, topo + 8, P["pele_s"])
    cx_olho = (ox + 0, ox + 2)
    for ex in cx_olho:
        pt(d, ex, topo + 4, P["olho"])
        pt(d, ex, topo + 5, P["olho"]) if not fem else None
    if fem:
        pt(d, ox + 3, topo + 3, P["olho"])   # cílio
        pt(d, ox + 1, topo + 5, P["olho"])
        pt(d, ox + 2, topo + 5, P["olho"])

    if cls == "guerreiro":
        cab = P["cabelo_c"] if fem else P["cabelo_m"]
        ret(d, ox - 4, topo - 1, ox + 3, topo + 2, cab)
        ret(d, ox - 4, topo + 2, ox - 3, topo + 6, cab)
        ret(d, ox + 1, topo + 2, ox + 3, topo + 2, cab)
        pt(d, ox + 2, topo - 2, cab)
        if fem:
            # cabelo longo caindo pelas costas e pelo ombro
            ret(d, ox - 7, topo, ox - 3, topo + 6, cab)
            ret(d, ox - 8, topo + 4, ox - 4, topo + 17, cab)
            ret(d, ox - 7, topo + 14, ox - 5, topo + 19, P["cabelo_c_s"])
            ret(d, ox - 8, topo + 5, ox - 8, topo + 15, P["cabelo_c_s"])
            pt(d, ox + 3, topo + 3, cab)                          # franja lateral
            pt(d, ox + 3, topo + 4, cab)
    elif cls == "mago":
        cor, sombra = (P["roxo"], P["roxo_s"]) if fem else (P["cinza"], P["cinza_s"])
        if fem:
            ret(d, ox - 5, topo + 1, ox - 3, topo + 12, P["cabelo_c"])
            ret(d, ox - 5, topo + 8, ox - 4, topo + 12, P["cabelo_c_s"])
            ret(d, ox + 3, topo + 3, ox + 3, topo + 4, P["cabelo_c"])
        else:
            poli(d, [(ox - 2, topo + 6), (ox + 3, topo + 6), (ox + 2, topo + 13), (ox - 1, topo + 12)], P["barba"])
            ret(d, ox - 3, topo + 6, ox - 2, topo + 8, P["barba"])
        ret(d, ox - 7, topo - 1, ox + 6, topo + 1, cor)                          # aba
        ret(d, ox - 7, topo + 1, ox + 6, topo + 1, sombra)
        poli(d, [(ox - 4, topo - 1), (ox + 4, topo - 1), (ox + 2, topo - 9), (ox - 1, topo - 9)], cor)
        ret(d, ox - 1, topo - 11, ox + 3, topo - 9, cor)                         # ponta caída
        pt(d, ox + 4, topo - 10, cor)
        pt(d, ox + 4, topo - 9, sombra)
        pt(d, ox - 2, topo - 4, P["amarelo"])
    elif cls == "arqueiro":
        if fem:
            ret(d, ox - 6, topo + 1, ox - 4, topo + 6, P["cabelo_f"])               # trança longa
            ret(d, ox - 7, topo + 5, ox - 5, topo + 16, P["cabelo_f"])
            ret(d, ox - 7, topo + 14, ox - 6, topo + 17, P["cabelo_c_s"])
        else:
            ret(d, ox - 4, topo + 1, ox - 3, topo + 6, P["cabelo_m"])
        ret(d, ox - 4, topo - 1, ox + 3, topo + 1, P["oliva"])                       # chapéu
        ret(d, ox - 4, topo + 1, ox - 3, topo + 2, P["oliva_s"])
        pt(d, ox + 4, topo, P["oliva"])
        lin(d, (ox + 1, topo - 1), (ox + 5, topo - 6), P["vermelho"], 1)             # pena
        pt(d, ox + 5, topo - 7, P["branco"])
    else:
        # capuz verde
        ret(d, ox - 5, topo - 1, ox + 4, topo + 1, P["verde"])
        ret(d, ox - 5, topo + 1, ox - 3, topo + 9, P["verde"])
        ret(d, ox + 4, topo + 1, ox + 4, topo + 7, P["verde"])
        ret(d, ox - 5, topo - 1, ox - 4, topo, P["verde_s"])
        if fem:
            ret(d, ox + 3, topo + 2, ox + 3, topo + 3, P["cabelo_f"])
        else:
            ret(d, ox - 1, topo + 7, ox + 3, topo + 8, P["marrom"])

    # ---- braço da frente + arma
    lin(d, ombro_f, mao, manga, 3)
    ret(d, mao[0] - 1, mao[1] - 1, mao[0], mao[1], P["pele"])
    if "arma" in pose and pose["arma"][0] == "arco" and "mao2" in pose:
        lin(d, ombro_t, mao2, manga, 3)                  # braço que puxa a corda, por cima do corpo
    if "arma" in pose:
        tipo, ang, comp, orbe = pose["arma"]
        desenhar_arma(d, tipo, mao if "hold" not in pose else
                      (ox + pose["hold"][0], oy + pose["hold"][1]), ang, comp, orbe)
    if "escudo" in pose:
        desenhar_escudo(d, ox + pose["escudo"][0], oy + pose["escudo"][1], grande=fem)
    if "frasco" in pose:
        desenhar_frasco(d, mao[0] + pose["frasco"][0], mao[1] + pose["frasco"][1], pose["frasco"][2])


# ---------------------------------------------------------------
# Efeitos (todos recebem d, ox, oy; sempre cores sólidas por causa do GIF)
# ---------------------------------------------------------------
def aura(raio, cor, cy=-14):
    def f(d, ox, oy):
        for x in range(-raio, raio + 1):
            for y in range(-raio, raio + 1):
                if x * x + y * y <= raio * raio and (x + y) % 2 == 0:
                    pt(d, ox + x, oy + cy + y, cor)
    return f


def arco(cx, cy, raio, a0, a1, cor, w=2):
    def f(d, ox, oy):
        d.arc([r(ox + cx - raio), r(oy + cy - raio), r(ox + cx + raio), r(oy + cy + raio)],
              a0, a1, fill=cor, width=w)
    return f


def brilhos(pts, cor, tam=1):
    def f(d, ox, oy):
        for x, y in pts:
            estrela(d, ox + x, oy + y, cor, tam)
    return f


def pontos(pts, cor):
    def f(d, ox, oy):
        for x, y in pts:
            pt(d, ox + x, oy + y, cor)
    return f


def bola_fogo(x, y, raio):
    def f(d, ox, oy):
        cx, cy = ox + x, oy + y
        disco(d, cx, cy, raio, P["vermelho"])
        if raio >= 3:
            disco(d, cx, cy, raio - 1, P["laranja"])
        if raio >= 4:
            disco(d, cx + 0.5, cy, raio - 3, P["amarelo"])
        if raio >= 6:
            disco(d, cx + 1, cy, raio - 5, P["branco"])
        for k in range(3):                           # chamas
            pt(d, cx - raio + k, cy - raio - 1 + k, P["laranja"])
            pt(d, cx + raio - 2 - k, cy - raio, P["amarelo"])
    return f


def rastro(x0, x1, y, raio):
    def f(d, ox, oy):
        for i, x in enumerate(range(x0, x1, 3)):
            rr = max(1, raio - (x1 - x) // 4)
            disco(d, ox + x, oy + y + (i % 2), rr, P["laranja"] if i % 2 else P["vermelho"])
    return f


def explosao(x, y, raio):
    def f(d, ox, oy):
        cx, cy = ox + x, oy + y
        for k in range(14):
            a = k * 2 * math.pi / 14
            rr = raio + (3 if k % 2 else 0)
            pt(d, cx + math.cos(a) * rr, cy + math.sin(a) * rr, P["amarelo"] if k % 2 else P["laranja"])
            lin(d, (cx + math.cos(a) * (raio - 3), cy + math.sin(a) * (raio - 3)),
                (cx + math.cos(a) * rr, cy + math.sin(a) * rr), P["laranja"], 1)
        disco(d, cx, cy, raio - 3, P["vermelho"])
        disco(d, cx, cy, max(1, raio - 5), P["amarelo"])
        disco(d, cx, cy, max(1, raio - 8), P["branco"])
    return f


def raio_magia(x, y, tam=2):
    def f(d, ox, oy):
        disco(d, ox + x, oy + y, tam, P["ciano"])
        disco(d, ox + x, oy + y, max(1, tam - 1), P["azul_c"])
        pt(d, ox + x, oy + y, P["branco"])
        for k in range(1, 5):
            pt(d, ox + x - tam - k * 2, oy + y + (k % 2) - 1, P["ciano"])
    return f


def onda_chao(x0, x1, cor=None):
    cor = cor or P["amarelo"]

    def f(d, ox, oy):
        for x in range(x0, x1, 2):
            pt(d, ox + x, oy, cor)
            pt(d, ox + x, oy - 1 - ((x // 2) % 3), cor)
        for k in range(3):
            lin(d, (ox + x1 - 2 - k * 3, oy - 2), (ox + x1 + 1 - k * 3, oy - 7 - k), cor, 1)
    return f


def exclamacao(x, y, cor=None):
    cor = cor or P["vermelho"]

    def f(d, ox, oy):
        ret(d, ox + x, oy + y, ox + x + 1, oy + y + 4, cor)
        ret(d, ox + x, oy + y + 6, ox + x + 1, oy + y + 7, cor)
    return f


def linhas_grito(cor=None):
    cor = cor or P["vermelho"]

    def f(d, ox, oy):
        cx, cy = ox + 2, oy - 28
        for ang in (20, 45, 70, 110, 135, 160):
            dx, dy = vec(ang)
            lin(d, (cx + dx * 9, cy + dy * 9), (cx + dx * 13, cy + dy * 13), cor, 1)
    return f


def cruzes_cura(pts, cor):
    def f(d, ox, oy):
        for x, y in pts:
            ret(d, ox + x, oy + y - 1, ox + x, oy + y + 1, cor)
            ret(d, ox + x - 1, oy + y, ox + x + 1, oy + y, cor)
    return f


def anel(raio, cor, cy=-1):
    def f(d, ox, oy):
        d.ellipse([r(ox - raio), r(oy + cy - raio // 3), r(ox + raio), r(oy + cy + raio // 3)],
                  outline=cor, width=1)
    return f


def seta(x, y, ang=0, comp=13):
    """Flecha em voo (x, y é a ponta). Cores sólidas por causa do GIF."""
    def f(d, ox, oy):
        dx, dy = vec(ang)
        gx, gy = -dy, dx
        tip = (ox + x, oy + y)
        tail = (tip[0] - dx * comp, tip[1] - dy * comp)
        lin(d, tail, tip, P["creme"], 1)
        poli(d, [(tip[0] + dx * 1.5, tip[1] + dy * 1.5),
                 (tip[0] - dx * 3 + gx * 1.6, tip[1] - dy * 3 + gy * 1.6),
                 (tip[0] - dx * 3 - gx * 1.6, tip[1] - dy * 3 - gy * 1.6)], P["aco_c"])
        for k in (0, 2):                                   # penas
            pt(d, tail[0] + dx * k + gx * 1.5, tail[1] + dy * k + gy * 1.5, P["vermelho"])
            pt(d, tail[0] + dx * k - gx * 1.5, tail[1] + dy * k - gy * 1.5, P["vermelho"])
        for k in (3, 6):                                   # rastro de vento
            pt(d, tail[0] - dx * k, tail[1] - dy * k, P["branco"])
    return f


def mira(x, y, cor=None):
    cor = cor or P["vermelho"]

    def f(d, ox, oy):
        cx, cy = ox + x, oy + y
        d.ellipse([r(cx - 6), r(cy - 6), r(cx + 6), r(cy + 6)], outline=cor, width=1)
        lin(d, (cx - 9, cy), (cx - 3, cy), cor, 1)
        lin(d, (cx + 3, cy), (cx + 9, cy), cor, 1)
        lin(d, (cx, cy - 9), (cx, cy - 3), cor, 1)
        lin(d, (cx, cy + 3), (cx, cy + 9), cor, 1)
    return f


def frame(dur=110, back=None, front=None, **pose):
    return dict(dur=dur, back=back or [], front=front or [], pose=pose)


# ---------------------------------------------------------------
# Animações por classe
# ---------------------------------------------------------------
def anim_guerreiro():
    esp = lambda ang, c=17: ("espada", ang, c, None)
    A = {}
    A["idle"] = [
        frame(220, mao=(9, -17), arma=esp(78), ag=0),
        frame(220, mao=(9, -16), arma=esp(80), ag=1),
        frame(220, mao=(9, -16), arma=esp(82), ag=1),
        frame(220, mao=(9, -17), arma=esp(80), ag=0),
    ]
    A["ataque"] = [
        frame(100, dx=-2, mao=(6, -26), arma=esp(120)),
        frame(100, dx=-3, mao=(3, -28), arma=esp(150)),
        frame(70, dx=3, mao=(12, -22), arma=esp(60),
              front=[arco(8, -22, 15, 285, 345, P["branco"], 2)]),
        frame(70, dx=6, mao=(14, -12), arma=esp(-25),
              front=[arco(8, -22, 15, 330, 45, P["branco"], 2), arco(8, -22, 12, 335, 40, P["azul_c"], 1)]),
        frame(100, dx=5, mao=(13, -13), arma=esp(-30)),
        frame(110, dx=2, mao=(10, -15), arma=esp(40)),
    ]
    def barreira(rr, cor):
        return arco(14, -16, rr, 300, 60, cor, 2)

    A["defesa"] = [
        frame(80, ag=1, mao=(8, -10), arma=esp(15), escudo=(8, -13)),
        frame(80, ag=2, mao=(8, -9), arma=esp(10), escudo=(11, -16),
              front=[brilhos([(20, -22)], P["branco"], 1)]),
        frame(70, ag=2, dx=-1, mao=(8, -9), arma=esp(10), escudo=(13, -17),
              front=[barreira(14, P["ouro"]), brilhos([(20, -18)], P["branco"], 3),
                     pontos([(17, -26), (23, -12), (21, -27), (24, -20)], P["amarelo"])]),
        frame(70, ag=2, dx=-2, mao=(8, -9), arma=esp(10), escudo=(13, -17),
              front=[barreira(17, P["amarelo"]), barreira(14, P["branco"]),
                     pontos([(19, -29), (26, -10), (24, -24)], P["amarelo"])]),
        frame(80, ag=2, dx=-1, mao=(8, -9), arma=esp(10), escudo=(12, -17),
              front=[barreira(15, P["ouro"]), pontos([(22, -22), (20, -12)], P["amarelo"])]),
        frame(90, ag=2, mao=(8, -9), arma=esp(10), escudo=(12, -17)),
        frame(100, ag=1, mao=(8, -10), arma=esp(15), escudo=(11, -16)),
    ]
    # enquanto o guerreiro está bloqueando, o jogo repete esta pose
    A["bloqueando"] = [
        frame(200, ag=2, mao=(8, -9), arma=esp(10), escudo=(12, -17),
              front=[pontos([(18, -22)], P["branco"])]),
        frame(200, ag=2, mao=(8, -9), arma=esp(10), escudo=(12, -16),
              front=[barreira(15, P["ouro"]), pontos([(17, -17)], P["branco"])]),
        frame(200, ag=3, mao=(8, -9), arma=esp(10), escudo=(12, -17),
              front=[barreira(15, P["amarelo"]), pontos([(18, -12)], P["branco"])]),
        frame(200, ag=2, mao=(8, -9), arma=esp(10), escudo=(12, -16),
              front=[barreira(15, P["ouro"]), pontos([(16, -22)], P["branco"])]),
    ]
    golpe = []
    for i, rr in enumerate((6, 9, 12, 15)):
        golpe.append(frame(110, ag=0, mao=(5, -29 + i), arma=esp(100 - i * 2),
                           back=[aura(rr, P["amarelo"], cy=-16)],
                           front=[brilhos([(-6 - i, -34 + i * 2), (10 + i, -38)], P["amarelo"], 1)]))
    golpe.append(frame(160, ag=0, mao=(3, -31), arma=esp(110),
                       back=[aura(17, P["branco"], cy=-16), aura(13, P["amarelo"], cy=-16)],
                       front=[brilhos([(-8, -36), (12, -40), (3, -44)], P["branco"], 2)]))
    golpe.append(frame(70, dx=7, mao=(15, -9), arma=esp(-35),
                       front=[arco(10, -26, 20, 300, 60, P["laranja"], 3), arco(10, -26, 17, 310, 55, P["amarelo"], 2),
                              arco(10, -26, 14, 320, 50, P["branco"], 1)]))
    golpe.append(frame(90, dx=7, ag=2, mao=(15, -8), arma=esp(-38),
                       front=[onda_chao(14, 44), brilhos([(26, -9), (34, -6)], P["branco"], 2)]))
    golpe.append(frame(110, dx=6, ag=1, mao=(14, -10), arma=esp(-30),
                       front=[onda_chao(20, 48, P["laranja"])]))
    golpe.append(frame(120, dx=2, mao=(10, -15), arma=esp(40)))
    A["golpe"] = golpe
    A["provocar"] = [
        frame(90, ag=0, mao=(8, -28), mao2=(-8, -26), arma=esp(90),
              front=[exclamacao(-3, -48)]),
        frame(90, ag=0, mao=(8, -30), mao2=(-8, -28), arma=esp(90), back=[aura(14, P["vermelho"])],
              front=[exclamacao(-3, -49), linhas_grito()]),
        frame(90, ag=0, mao=(8, -29), mao2=(-8, -27), arma=esp(92), back=[aura(18, P["vermelho"])],
              front=[exclamacao(-3, -48), linhas_grito()]),
        frame(90, ag=0, mao=(8, -30), mao2=(-8, -28), arma=esp(88), back=[aura(14, P["vermelho"])],
              front=[exclamacao(-3, -49), linhas_grito()]),
        frame(90, ag=0, mao=(8, -29), mao2=(-8, -27), arma=esp(92), back=[aura(18, P["vermelho"])],
              front=[exclamacao(-3, -48), linhas_grito()]),
        frame(110, ag=0, mao=(9, -22), arma=esp(85), back=[aura(11, P["vermelho"])]),
        frame(110, ag=0, mao=(9, -17), arma=esp(80)),
    ]
    A["caido"] = [frame(200, ag=10, mao=(8, -3), mao2=(-6, -3), arma=("espada", 4, 15, None))]
    return A


def anim_mago():
    caj = lambda ang, orb=None, c=24: ("cajado", ang, c, orb)
    orb = lambda raio=2, cor=None: (cor or P["ciano"], raio)
    A = {}
    A["idle"] = [
        frame(200, mao=(8, -14), arma=caj(86, orb(2)), ag=0),
        frame(200, mao=(8, -14), arma=caj(86, orb(3)), ag=0, front=[pontos([(8, -42)], P["azul_c"])]),
        frame(200, mao=(8, -13), arma=caj(86, orb(3)), ag=1, front=[pontos([(6, -44)], P["azul_c"])]),
        frame(200, mao=(8, -14), arma=caj(86, orb(2)), ag=0),
    ]
    A["magia"] = [
        frame(100, mao=(6, -18), arma=caj(100, orb(3)), dx=-1),
        frame(100, mao=(10, -20), arma=caj(35, orb(4, P["azul_c"])), dx=1),
    ]
    tip = lambda: ponta_arma(OX + 3, OY, (10, -20), 30, 24)
    tx, ty = tip()
    px_, py_ = int(tx - OX - 3), int(ty - OY)
    A["magia"] += [
        frame(80, mao=(10, -20), arma=caj(30, orb(5, P["branco"])), dx=3,
              front=[brilhos([(px_ + 3, py_ - 2)], P["branco"], 3)]),
        frame(70, mao=(10, -20), arma=caj(30, orb(2)), dx=3, front=[raio_magia(px_ + 8, py_, 2)]),
        frame(70, mao=(10, -20), arma=caj(30, orb(2)), dx=2, front=[raio_magia(px_ + 18, py_, 2)]),
        frame(70, mao=(10, -20), arma=caj(30, orb(2)), dx=1, front=[raio_magia(px_ + 28, py_ + 1, 3)]),
        frame(90, mao=(9, -17), arma=caj(60, orb(2)),
              front=[brilhos([(px_ + 33, py_ + 1)], P["branco"], 3),
                     pontos([(px_ + 30, py_ - 4), (px_ + 37, py_ + 4), (px_ + 36, py_ - 3)], P["ciano"])]),
        frame(110, mao=(8, -14), arma=caj(80, orb(2))),
    ]
    A["bola_fogo"] = []
    for i, rr in enumerate((2, 4, 6, 8)):
        pos = ponta_arma(0, 0, (6, -17), 95, 20)
        A["bola_fogo"].append(frame(110, mao=(6, -17), arma=caj(95, orb(2, P["laranja"]), 20), dx=-1,
                                    front=[bola_fogo(int(pos[0] + 2), int(pos[1] - rr + 1), rr),
                                           pontos([(-6, -26 - i), (14, -30)], P["laranja"])]))
    pos = ponta_arma(0, 0, (6, -17), 95, 20)
    A["bola_fogo"].append(frame(150, mao=(6, -18), arma=caj(95, orb(2, P["laranja"]), 20), dx=-1,
                                back=[aura(11, P["laranja"], cy=-18)],
                                front=[bola_fogo(int(pos[0] + 2), int(pos[1] - 8), 9),
                                       pontos([(-6, -30), (14, -34), (18, -26)], P["amarelo"])]))
    A["bola_fogo"] += [
        frame(80, mao=(12, -20), arma=caj(20, orb(2, P["laranja"])), dx=3,
              front=[bola_fogo(26, -24, 9)]),
        frame(70, mao=(12, -20), arma=caj(20, orb(2)), dx=3,
              front=[rastro(26, 34, -24, 6), bola_fogo(38, -23, 9)]),
        frame(70, mao=(12, -20), arma=caj(20, orb(2)), dx=2,
              front=[rastro(30, 48, -23, 6), bola_fogo(52, -22, 9)]),
        frame(90, mao=(11, -18), arma=caj(40, orb(2)), dx=1, front=[explosao(55, -20, 13)]),
        frame(110, mao=(10, -16), arma=caj(60, orb(2)), front=[explosao(55, -20, 9),
                                                              pontos([(44, -34), (62, -10), (48, -6)], P["amarelo"])]),
        frame(110, mao=(8, -14), arma=caj(80, orb(2)), front=[pontos([(52, -28), (58, -12)], P["laranja"])]),
    ]
    A["cajado"] = [
        frame(100, dx=-2, mao=(5, -26), arma=caj(125, orb(2), 22)),
        frame(100, dx=-3, mao=(3, -28), arma=caj(150, orb(2), 22)),
        frame(70, dx=3, mao=(11, -22), arma=caj(60, orb(3), 22),
              front=[arco(8, -22, 15, 285, 345, P["azul_c"], 2)]),
        frame(70, dx=6, mao=(13, -12), arma=caj(-20, orb(3), 22),
              front=[arco(8, -22, 15, 330, 45, P["azul_c"], 2), brilhos([(34, -8)], P["branco"], 2)]),
        frame(100, dx=5, mao=(12, -13), arma=caj(-25, orb(2), 22)),
        frame(110, dx=1, mao=(9, -15), arma=caj(60, orb(2), 22)),
    ]
    stf = ("cajado", 90, 28, (P["ciano"], 2))
    A["pocao"] = [
        frame(100, mao=(9, -13), mao2=(-8, -13), hold=(-8, -13), arma=("cajado", 90, 28, (P["ciano"], 2)),
              frasco=(2, 0, 0)),
        frame(100, mao=(8, -20), mao2=(-8, -13), hold=(-8, -13), arma=("cajado", 90, 28, (P["ciano"], 2)),
              frasco=(2, -1, 0)),
        frame(110, mao=(5, -26), mao2=(-8, -13), hold=(-8, -13), arma=("cajado", 90, 28, (P["ciano"], 2)),
              frasco=(2, -2, 1)),
        frame(110, mao=(5, -27), mao2=(-8, -13), hold=(-8, -13), arma=("cajado", 90, 28, (P["ciano"], 3)),
              frasco=(2, -2, 1), back=[aura(10, P["ciano"])],
              front=[brilhos([(-12, -30), (14, -26)], P["azul_c"], 1)]),
        frame(110, mao=(5, -27), mao2=(-8, -13), hold=(-8, -13), arma=("cajado", 90, 28, (P["azul_c"], 3)),
              frasco=(2, -2, 1), back=[aura(14, P["ciano"])],
              front=[brilhos([(-12, -36), (14, -32), (2, -46)], P["branco"], 1), anel(12, P["azul_c"])]),
        frame(110, mao=(8, -19), mao2=(-8, -13), hold=(-8, -13), arma=("cajado", 90, 28, (P["azul_c"], 3)),
              back=[aura(11, P["ciano"])],
              front=[brilhos([(-10, -40), (12, -38)], P["azul_c"], 1), anel(15, P["ciano"])]),
        frame(120, mao=(8, -14), arma=caj(86, orb(2))),
    ]
    A["caido"] = [frame(200, ag=10, mao=(8, -3), mao2=(-6, -3), arma=("cajado", 4, 24, (P["cinza"], 2)))]
    return A


def anim_sacerdote():
    mac = lambda ang, c=22: ("maca", ang, c, None)
    A = {}
    A["idle"] = [
        frame(220, mao=(8, -15), arma=mac(88), ag=0),
        frame(220, mao=(8, -14), arma=mac(88), ag=1),
        frame(220, mao=(8, -14), arma=mac(88), ag=1),
        frame(220, mao=(8, -15), arma=mac(88), ag=0),
    ]
    A["ataque"] = [
        frame(100, dx=-2, mao=(5, -26), arma=mac(125, 20)),
        frame(100, dx=-3, mao=(3, -28), arma=mac(150, 20)),
        frame(70, dx=3, mao=(11, -22), arma=mac(60, 20), front=[arco(8, -22, 14, 285, 345, P["amarelo"], 2)]),
        frame(70, dx=6, mao=(13, -12), arma=mac(-20, 20),
              front=[arco(8, -22, 14, 330, 45, P["amarelo"], 2), brilhos([(33, -8)], P["branco"], 2)]),
        frame(100, dx=5, mao=(12, -13), arma=mac(-25, 20)),
        frame(110, dx=1, mao=(9, -15), arma=mac(70, 20)),
    ]
    A["cura"] = [
        frame(100, mao=(7, -22), arma=mac(95)),
        frame(100, mao=(6, -26), arma=mac(95), back=[aura(8, P["verde_c"], cy=-18)]),
        frame(110, mao=(6, -27), arma=mac(95), back=[aura(12, P["verde_c"], cy=-18)],
              front=[cruzes_cura([(-9, -30), (15, -26)], P["verde_c"])]),
        frame(110, mao=(6, -27), arma=mac(95), back=[aura(16, P["verde_c"], cy=-18)],
              front=[cruzes_cura([(-11, -38), (17, -34), (4, -50)], P["branco"]),
                     brilhos([(-14, -24), (20, -20)], P["amarelo"], 1)]),
        frame(110, mao=(6, -27), arma=mac(95), back=[aura(18, P["amarelo"], cy=-18)],
              front=[cruzes_cura([(-12, -44), (18, -40), (6, -52)], P["verde_c"]),
                     brilhos([(-15, -32), (22, -28)], P["amarelo"], 1), anel(14, P["verde_c"])]),
        frame(110, mao=(7, -20), arma=mac(92), back=[aura(12, P["verde_c"], cy=-18)],
              front=[cruzes_cura([(-10, -46), (16, -44)], P["verde_c"]), anel(16, P["verde_c"])]),
        frame(120, mao=(8, -15), arma=mac(88)),
    ]
    A["caido"] = [frame(200, ag=10, mao=(8, -3), mao2=(-6, -3), arma=("maca", 4, 20, None))]
    return A


def anim_arqueiro():
    def ap(mao, ang, t=0.0, fl=False, comp=22, pull=None, **extra):
        """Pose do arco: t é o quanto a corda está puxada (0 a 1), fl mostra a flecha na corda."""
        dx, dy = vec(ang)
        d = dict(mao=mao, arma=("arco", ang, comp, (t, fl)))
        if pull if pull is not None else (t > 0 or fl):
            d["mao2"] = (mao[0] - dx * (3 + 9 * t), mao[1] - dy * (3 + 9 * t))
        d.update(extra)
        return d

    A = {}
    A["idle"] = [
        frame(220, **ap((10, -16), 10, ag=0)),
        frame(220, **ap((10, -15), 12, ag=1)),
        frame(220, **ap((10, -15), 12, ag=1)),
        frame(220, **ap((10, -16), 10, ag=0)),
    ]
    A["ataque"] = [
        frame(100, **ap((10, -22), 4, 0.3, True, dx=-1)),
        frame(100, **ap((10, -22), 4, 0.7, True, dx=-2)),
        frame(110, **ap((10, -22), 4, 1.0, True, dx=-2)),
        frame(60, **ap((11, -22), 4, 0.0, False, dx=0, pull=False), front=[seta(32, -22)]),
        frame(60, **ap((11, -22), 4, 0.0, False, dx=0, pull=False), front=[seta(50, -22)]),
        frame(80, **ap((11, -22), 4, 0.0, False, dx=0, pull=False),
              front=[seta(66, -22), brilhos([(70, -22)], P["branco"], 2)]),
        frame(110, **ap((10, -18), 8)),
    ]
    A["tiro_duplo"] = [
        frame(80, **ap((10, -22), 4, 0.6, True, dx=-1)),
        frame(70, **ap((10, -22), 4, 1.0, True, dx=-2)),
        frame(60, **ap((11, -22), 4, 0.0, False, pull=False), front=[seta(30, -22)]),
        frame(60, **ap((10, -22), 4, 0.5, True, dx=-1), front=[seta(48, -22)]),
        frame(60, **ap((10, -22), 4, 1.0, True, dx=-2), front=[seta(64, -22), brilhos([(70, -22)], P["branco"], 2)]),
        frame(60, **ap((11, -22), 4, 0.0, False, pull=False), front=[seta(30, -22)]),
        frame(60, **ap((11, -22), 4, 0.0, False, pull=False), front=[seta(48, -22)]),
        frame(80, **ap((11, -22), 4, 0.0, False, pull=False),
              front=[seta(64, -22), brilhos([(70, -22)], P["branco"], 2)]),
        frame(110, **ap((10, -18), 8)),
    ]
    A["tiro_certeiro"] = [
        frame(100, **ap((9, -20), 6, 0.2, True, dx=-1)),
        frame(120, **ap((10, -22), 3, 0.7, True, dx=-2), front=[mira(62, -22)]),
        frame(150, **ap((10, -22), 3, 1.0, True, dx=-2), back=[aura(10, P["amarelo"], cy=-18)],
              front=[mira(62, -22), brilhos([(15, -28)], P["amarelo"], 1)]),
        frame(150, **ap((10, -22), 3, 1.0, True, dx=-2), back=[aura(13, P["amarelo"], cy=-18)],
              front=[mira(62, -22), brilhos([(15, -28), (-8, -30)], P["branco"], 2)]),
        frame(50, **ap((12, -22), 3, 0.0, False, dx=1, pull=False),
              front=[seta(38, -22, 3, 16), arco(8, -22, 15, 330, 45, P["amarelo"], 2)]),
        frame(50, **ap((12, -22), 3, 0.0, False, dx=1, pull=False), front=[seta(62, -22, 3, 16)]),
        frame(90, **ap((11, -22), 3, 0.0, False, pull=False), front=[explosao(66, -22, 9)]),
        frame(110, **ap((10, -19), 8), front=[pontos([(60, -30), (72, -14), (62, -12)], P["amarelo"])]),
    ]
    A["chuva"] = [
        frame(100, **ap((9, -31), 62, 0.5, True, dx=-1)),
        frame(120, **ap((9, -31), 62, 1.0, True, dx=-2), back=[aura(9, P["laranja"], cy=-22)]),
        frame(60, **ap((10, -31), 62, 0.0, False, pull=False), front=[seta(20, -42, 62, 14)]),
        frame(60, **ap((10, -31), 62, 0.0, False, pull=False), front=[seta(28, -50, 62, 14)]),
        frame(70, **ap((10, -28), 62, 0.0, False, pull=False),
              front=[seta(38, -44, -80), seta(50, -46, -80), seta(60, -42, -80), seta(68, -46, -80)]),
        frame(70, **ap((10, -26), 40, 0.0, False, pull=False),
              front=[seta(38, -32, -80), seta(50, -34, -80), seta(60, -30, -80), seta(68, -34, -80)]),
        frame(70, **ap((10, -24), 30, 0.0, False, pull=False),
              front=[seta(38, -22, -80), seta(50, -24, -80), seta(60, -20, -80), seta(68, -24, -80)]),
        frame(80, **ap((10, -20), 20, 0.0, False, pull=False),
              front=[seta(38, -6, -80), seta(50, -8, -80), seta(60, -4, -80), seta(68, -8, -80),
                     brilhos([(42, -4), (56, -3), (66, -3)], P["amarelo"], 1)]),
        frame(110, **ap((10, -18), 10), front=[pontos([(40, -6), (54, -8), (64, -5), (70, -9)], P["amarelo"])]),
    ]
    A["caido"] = [frame(200, ag=10, mao=(8, -3), mao2=(-6, -3), arma=("arco", 90, 18, (0, False)))]
    return A


CLASSES_ANIM = {"guerreiro": anim_guerreiro, "mago": anim_mago, "sacerdote": anim_sacerdote, "arqueiro": anim_arqueiro}


# ---------------------------------------------------------------
# Renderização
# ---------------------------------------------------------------
def contorno(camada):
    alfa = camada.split()[3]
    dilatada = alfa.filter(ImageFilter.MaxFilter(3))
    borda = Image.new("L", camada.size, 0)
    borda.putdata([255 if (dd > 0 and aa == 0) else 0
                   for dd, aa in zip(dilatada.getdata(), alfa.getdata())])
    saida = Image.new("RGBA", camada.size, (0, 0, 0, 0))
    saida.paste(P["contorno"], mask=borda)
    return Image.alpha_composite(saida, camada)


def renderizar(cls, sexo, fr):
    pose = fr["pose"]
    ox, oy = OX + pose.get("dx", 0), OY + pose.get("dy", 0)
    base = Image.new("RGBA", (LW, LH), (0, 0, 0, 0))
    db = ImageDraw.Draw(base)
    # sombra no chão
    db.ellipse([ox - 9, OY - 1, ox + 9, OY + 2], fill=(40, 40, 60, 255))
    for f in fr["back"]:
        f(db, ox, oy)
    camada = Image.new("RGBA", (LW, LH), (0, 0, 0, 0))
    desenhar_personagem(ImageDraw.Draw(camada), cls, sexo, pose)
    base = Image.alpha_composite(base, contorno(camada))
    df = ImageDraw.Draw(base)
    for f in fr["front"]:
        f(df, ox, oy)
    return base.transpose(Image.FLIP_LEFT_RIGHT)      # heróis ficam à direita e olham para a esquerda


def cinza(img):
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            rr, g, b, a = px[x, y]
            if a:
                v = int((rr + g + b) / 3 * 0.8)
                px[x, y] = (v, v, v + 6 if v < 249 else v, a)
    return img


def salvar_gif(quadros, duracoes, caminho):
    cores = {}
    for q in quadros:
        for c in set(q.getdata()):
            if c[3] != 0:
                cores.setdefault(c[:3], len(cores) + 1)
    assert len(cores) < 255, "muitas cores"
    paleta = [0, 0, 0]
    for rgb in cores:
        paleta += list(rgb)
    paleta += [0] * (768 - len(paleta))
    ps = []
    for q in quadros:
        p = Image.new("P", q.size, 0)
        p.putpalette(paleta)
        p.putdata([0 if c[3] == 0 else cores[c[:3]] for c in q.getdata()])
        ps.append(p)
    ps[0].save(caminho, save_all=True, append_images=ps[1:], duration=duracoes,
               loop=0, transparency=0, disposal=2, optimize=False)


def main():
    os.makedirs(os.path.join(PASTA, "gif"), exist_ok=True)
    caminho_json = os.path.join(PASTA, "frames", "duracoes.json")
    duracoes = {}
    if os.path.exists(caminho_json):          # mantém as durações dos monstros
        with open(caminho_json, encoding="utf-8") as f:
            duracoes = json.load(f)
    total = 0
    for cls, fabrica in CLASSES_ANIM.items():
        anims = fabrica()
        for sexo in ("masculino", "feminino"):
            pasta_frames = os.path.join(PASTA, "frames", f"{cls}_{sexo}")
            os.makedirs(pasta_frames, exist_ok=True)
            for nome, frames in anims.items():
                imgs = [renderizar(cls, sexo, fr) for fr in frames]
                if nome == "caido":
                    imgs = [cinza(i) for i in imgs]
                durs = [fr["dur"] for fr in frames]
                duracoes[f"{cls}_{sexo}/{nome}"] = durs
                for n, im in enumerate(imgs):
                    im.resize((LW * ESC_JOGO, LH * ESC_JOGO), Image.NEAREST).save(
                        os.path.join(pasta_frames, f"{nome}_{n}.png"))
                grandes = [im.resize((LW * ESC_GIF, LH * ESC_GIF), Image.NEAREST) for im in imgs]
                salvar_gif(grandes, durs, os.path.join(PASTA, "gif", f"{cls}_{sexo}_{nome}.gif"))
                total += 1
    with open(caminho_json, "w", encoding="utf-8") as f:
        json.dump(duracoes, f, indent=1)
    print(f"{total} animações geradas em '{PASTA}/'.")


if __name__ == "__main__":
    main()
