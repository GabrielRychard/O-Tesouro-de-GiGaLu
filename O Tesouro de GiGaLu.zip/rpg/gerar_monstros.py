"""
Gerador de sprites dos monstros (originais, pixel art) para o RPG de turnos.
Precisa do gerar_sprites.py na mesma pasta.

Rode:  python gerar_monstros.py
Gera em sprites/gif e sprites/frames/monstro_<tipo>/ (e atualiza duracoes.json).
Os monstros são desenhados olhando para a direita e espelhados (olham os heróis).
"""
import json
import math
import os

from PIL import Image, ImageDraw

import gerar_sprites as g
from gerar_sprites import (P, hexa, pt, ret, lin, disco, poli, vec, contorno, cinza,
                           salvar_gif, arco, brilhos, pontos, aura, explosao, frame)

ESC_GIF, ESC_JOGO = 4, 2
PASTA = g.PASTA

C = {
    "gob": hexa("#5fae4a"), "gob_s": hexa("#3f7f35"),
    "mor": hexa("#5a3a82"), "mor_s": hexa("#3d2760"), "mor_c": hexa("#7b55a8"),
    "sli": hexa("#4fc878"), "sli_s": hexa("#2f9a58"), "sli_c": hexa("#a8f0bd"),
    "ogr": hexa("#8c9c5a"), "ogr_s": hexa("#667338"), "ogr_c": hexa("#b4c27e"),
    "dra": hexa("#c32a2a"), "dra_s": hexa("#8f1b22"), "dra_c": hexa("#e85a3a"),
    "asa": hexa("#7a1c3a"), "bege": hexa("#ebb96e"), "bege_s": hexa("#c48f4a"),
    "osso": hexa("#efe6c8"),
}

TAMANHOS = {"goblin": (52, 48), "morcego": (56, 52), "slime": (52, 40),
            "ogro": (60, 62), "tiamat": (160, 88)}


def xis(d, x, y, cor=None):
    cor = cor or P["olho"]
    for k in (-1, 0, 1):
        pt(d, x + k, y + k, cor)
        pt(d, x + k, y - k, cor)


# ---------------------------------------------------------------
# Goblin
# ---------------------------------------------------------------
def goblin(d, cx, gy, p):
    x, y = cx + p.get("dx", 0), gy + p.get("dy", 0)
    if p.get("morto"):
        ret(d, x - 11, y - 6, x + 5, y, C["gob"])
        ret(d, x - 11, y - 3, x - 4, y, P["marrom"])
        disco(d, x + 9, y - 5, 5, C["gob"])
        poli(d, [(x + 6, y - 9), (x + 3, y - 15), (x + 10, y - 10)], C["gob"])
        xis(d, x + 10, y - 6)
        lin(d, (x - 16, y - 1), (x - 24, y - 1), P["aco_c"], 1)
        return
    ret(d, x - 4, y - 7, x - 2, y, C["gob_s"])
    ret(d, x + 1, y - 7, x + 3, y, C["gob_s"])
    ret(d, x - 5, y - 1, x - 2, y, P["marrom_s"])
    ret(d, x + 1, y - 1, x + 4, y, P["marrom_s"])
    ret(d, x - 5, y - 17, x + 4, y - 7, C["gob"])
    ret(d, x - 4, y - 9, x + 3, y - 5, P["marrom"])
    ret(d, x - 5, y - 17, x - 4, y - 8, C["gob_s"])
    lin(d, (x - 4, y - 15), (x - 7, y - 10), C["gob"], 2)
    ret(d, x - 4, y - 27, x + 4, y - 18, C["gob"])
    poli(d, [(x - 4, y - 25), (x - 12, y - 28), (x - 4, y - 21)], C["gob"])
    poli(d, [(x + 4, y - 25), (x + 11, y - 30), (x + 4, y - 21)], C["gob"])
    pt(d, x + 1, y - 24, P["amarelo"]); pt(d, x + 3, y - 24, P["amarelo"])
    pt(d, x + 2, y - 24, P["olho"]); pt(d, x + 4, y - 24, P["olho"])
    ret(d, x + 1, y - 20, x + 4, y - 20, P["marrom_s"])
    pt(d, x + 2, y - 19, P["branco"]); pt(d, x + 4, y - 19, P["branco"])
    mao = (x + p["mao"][0], y + p["mao"][1])
    lin(d, (x + 4, y - 15), mao, C["gob"], 2)
    dx, dy = vec(p["ang"])
    lin(d, mao, (mao[0] + dx * 9, mao[1] + dy * 9), P["aco_c"], 1)
    lin(d, (mao[0] - dy * 2, mao[1] + dx * 2), (mao[0] + dy * 2, mao[1] - dx * 2), P["marrom_s"], 1)


def anim_goblin():
    return {
        "idle": [frame(220, mao=(8, -11), ang=60), frame(220, mao=(8, -12), ang=65, dy=-1),
                 frame(220, mao=(8, -12), ang=70, dy=-1), frame(220, mao=(8, -11), ang=60)],
        "ataque": [frame(100, dx=-2, mao=(4, -21), ang=120), frame(90, dx=0, mao=(6, -23), ang=130),
                   frame(70, dx=8, mao=(13, -15), ang=20, front=[arco(14, -18, 12, 290, 350, P["branco"], 2)]),
                   frame(70, dx=11, mao=(15, -9), ang=-30, front=[arco(14, -18, 12, 330, 40, P["branco"], 2)]),
                   frame(110, dx=4, mao=(9, -12), ang=50)],
        "morto": [frame(200, morto=True)],
    }


# ---------------------------------------------------------------
# Morcego
# ---------------------------------------------------------------
def morcego(d, cx, gy, p):
    x, y = cx + p.get("dx", 0), gy - 20 + p.get("dy", 0)
    if p.get("morto"):
        y = gy
        poli(d, [(cx - 12, y), (cx - 6, y - 7), (cx + 6, y - 7), (cx + 12, y)], C["mor_s"])
        disco(d, cx, y - 4, 6, C["mor"])
        disco(d, cx + 6, y - 6, 4, C["mor"])
        xis(d, cx + 7, y - 6, P["vermelho"])
        return
    a = p.get("asa", 150)
    S = (x - 1, y - 3)
    pts = [S]
    for k, (da, comp) in enumerate(((0, 22), (-26, 25), (-52, 21), (-76, 15))):
        dx, dy = vec(a + da)
        pts.append((S[0] + dx * comp, S[1] + dy * comp))
    poli(d, pts, C["mor_s"])
    for q in pts[1:]:
        lin(d, S, q, C["mor_c"], 1)
    disco(d, x, y, 7, C["mor"])
    ret(d, x - 3, y + 2, x + 4, y + 6, C["mor_c"])
    ret(d, x - 1, y + 7, x, y + 9, C["mor_s"]); ret(d, x + 2, y + 7, x + 3, y + 9, C["mor_s"])
    disco(d, x + 6, y - 5, 4, C["mor"])
    poli(d, [(x + 3, y - 8), (x + 2, y - 15), (x + 6, y - 9)], C["mor"])
    poli(d, [(x + 7, y - 9), (x + 10, y - 14), (x + 9, y - 7)], C["mor"])
    pt(d, x + 7, y - 6, P["vermelho"]); pt(d, x + 8, y - 6, P["amarelo"]) if p.get("boca") else pt(d, x + 8, y - 6, P["vermelho"])
    ret(d, x + 8, y - 3, x + 9, y - 3, P["branco"])
    if p.get("boca"):
        pt(d, x + 8, y - 2, P["branco"]); pt(d, x + 9, y - 1, P["vermelho"])
    else:
        pt(d, x + 8, y - 2, P["branco"])


def anim_morcego():
    return {
        "idle": [frame(130, asa=110), frame(130, asa=150, dy=1), frame(130, asa=195, dy=2), frame(130, asa=150, dy=1)],
        "ataque": [frame(100, dx=-3, asa=100, dy=-2), frame(90, dx=-5, asa=95, dy=-4),
                   frame(70, dx=9, dy=5, asa=190, boca=True,
                         front=[arco(14, 0, 12, 300, 20, P["branco"], 2)]),
                   frame(70, dx=14, dy=7, asa=200, boca=True, front=[arco(14, 2, 12, 330, 60, P["branco"], 2)]),
                   frame(110, dx=5, dy=2, asa=140)],
        "morto": [frame(200, morto=True)],
    }


# ---------------------------------------------------------------
# Slime
# ---------------------------------------------------------------
def slime(d, cx, gy, p):
    x, y = cx + p.get("dx", 0), gy + p.get("dy", 0)
    if p.get("morto"):
        d.ellipse([x - 16, y - 5, x + 16, y], fill=C["sli_s"])
        d.ellipse([x - 12, y - 5, x + 12, y - 1], fill=C["sli"])
        xis(d, x - 3, y - 3); xis(d, x + 5, y - 3)
        return
    w, h = 24 * p.get("sx", 1), 18 * p.get("sy", 1)
    d.ellipse([x - w / 2 - 1, y - h, x + w / 2 + 1, y], fill=C["sli_s"])
    d.ellipse([x - w / 2 + 1, y - h + 1, x + w / 2 - 1, y - 1], fill=C["sli"])
    ret(d, x - w / 4, y - h + 3, x - w / 4 + 2, y - h + 4, C["sli_c"])
    ret(d, x - w / 4 - 2, y - h + 5, x - w / 4 - 1, y - h + 6, C["sli_c"])
    ey = y - h * 0.55
    for ex in (x - 3, x + 4):
        ret(d, ex, ey - 2, ex + 2, ey + 1, P["branco"])
        pt(d, ex + 2, ey, P["olho"]); pt(d, ex + 2, ey - 1, P["olho"])
    if p.get("boca"):
        ret(d, x, ey + 3, x + 4, ey + 5, P["olho"])
    else:
        ret(d, x + 1, ey + 3, x + 4, ey + 3, P["olho"])
    pt(d, x - 6, y - 4, C["sli_c"]); pt(d, x + 6, y - 6, C["sli_c"])


def anim_slime():
    return {
        "idle": [frame(180, sx=1, sy=1), frame(180, sx=1.08, sy=0.92), frame(180, sx=1, sy=1),
                 frame(180, sx=0.94, sy=1.08)],
        "ataque": [frame(100, sx=1.2, sy=0.75), frame(90, sx=0.85, sy=1.3, dy=-6),
                   frame(70, dx=10, dy=-4, sx=1.1, sy=1.0, boca=True),
                   frame(70, dx=16, dy=0, sx=1.3, sy=0.75, boca=True,
                         front=[pontos([(24, -4), (28, -8), (30, -2), (22, -9)], C["sli_c"])]),
                   frame(110, dx=6, sx=1.1, sy=0.9)],
        "morto": [frame(200, morto=True)],
    }


# ---------------------------------------------------------------
# Ogro
# ---------------------------------------------------------------
def ogro(d, cx, gy, p):
    x, y = cx + p.get("dx", 0), gy + p.get("dy", 0)
    if p.get("morto"):
        ret(d, x - 14, y - 9, x + 8, y, C["ogr"])
        ret(d, x - 14, y - 5, x - 3, y, P["marrom"])
        disco(d, x + 13, y - 7, 7, C["ogr"])
        pt(d, x + 17, y - 4, P["branco"])
        xis(d, x + 14, y - 9)
        lin(d, (x - 20, y - 2), (x - 34, y - 2), P["marrom"], 3)
        return
    ret(d, x - 7, y - 14, x - 2, y, C["ogr_s"]); ret(d, x + 1, y - 14, x + 7, y, C["ogr_s"])
    ret(d, x - 8, y - 2, x - 2, y, P["marrom_s"]); ret(d, x + 1, y - 2, x + 8, y, P["marrom_s"])
    lin(d, (x - 9, y - 31), (x - 12, y - 17), C["ogr"], 5)
    ret(d, x - 10, y - 36, x + 9, y - 14, C["ogr"])
    ret(d, x - 10, y - 36, x - 8, y - 14, C["ogr_s"])
    ret(d, x - 10, y - 20, x + 9, y - 13, P["marrom"])
    ret(d, x - 1, y - 20, x + 1, y - 18, P["ouro"])
    ret(d, x - 3, y - 30, x + 6, y - 24, C["ogr_c"])
    ret(d, x - 5, y - 48, x + 6, y - 37, C["ogr"])
    ret(d, x - 5, y - 37, x - 3, y - 36, C["ogr_s"])
    ret(d, x - 6, y - 50, x + 3, y - 48, P["marrom_s"])
    pt(d, x + 1, y - 44, P["vermelho"]); pt(d, x + 4, y - 44, P["vermelho"])
    ret(d, x - 1, y - 45, x + 5, y - 45, C["ogr_s"])
    ret(d, x, y - 40, x + 5, y - 39, C["ogr_s"])
    pt(d, x + 1, y - 40, C["osso"]); pt(d, x + 4, y - 40, C["osso"])
    pt(d, x + 1, y - 41, C["osso"]); pt(d, x + 4, y - 41, C["osso"])
    mao = (x + p["mao"][0], y + p["mao"][1])
    lin(d, (x + 9, y - 31), mao, C["ogr"], 5)
    disco(d, mao[0], mao[1], 3, C["ogr_c"])
    dx, dy = vec(p["ang"])
    lin(d, (mao[0] - dx * 4, mao[1] - dy * 4), (mao[0] + dx * 22, mao[1] + dy * 22), P["marrom"], 3)
    lin(d, (mao[0] + dx * 14, mao[1] + dy * 14), (mao[0] + dx * 23, mao[1] + dy * 23), P["marrom_s"], 5)
    for k in (15, 19, 23):
        pt(d, mao[0] + dx * k - dy * 3, mao[1] + dy * k + dx * 3, C["osso"])


def anim_ogro():
    return {
        "idle": [frame(260, mao=(11, -17), ang=70), frame(260, mao=(11, -18), ang=72, dy=-1),
                 frame(260, mao=(11, -18), ang=74, dy=-1), frame(260, mao=(11, -17), ang=70)],
        "ataque": [frame(120, dx=-2, mao=(8, -34), ang=115), frame(120, dx=-3, mao=(5, -38), ang=140),
                   frame(70, dx=5, mao=(14, -28), ang=60, front=[arco(10, -30, 22, 285, 345, P["branco"], 2)]),
                   frame(80, dx=9, mao=(16, -12), ang=-35,
                         front=[arco(10, -30, 22, 330, 60, P["branco"], 3),
                                pontos([(34, -4), (38, -9), (40, -2)], P["amarelo"])]),
                   frame(110, dx=8, mao=(15, -11), ang=-40,
                         front=[pontos([(36, -3), (41, -7), (44, -1), (30, -8)], P["amarelo"])]),
                   frame(120, dx=3, mao=(11, -16), ang=60)],
        "morto": [frame(200, morto=True)],
    }


# ---------------------------------------------------------------
# Tiamat (dragão)
# ---------------------------------------------------------------
def tiamat(d, cx, gy, p):
    x, y = cx + p.get("dx", 0), gy + p.get("dy", 0)
    furioso = p.get("furioso")
    cor, cor_s = (C["dra_c"], C["dra"]) if furioso else (C["dra"], C["dra_s"])
    if p.get("morto"):
        ret(d, x - 30, y - 12, x + 14, y, C["dra_s"])
        d.ellipse([x - 24, y - 20, x + 8, y], fill=C["dra_s"])
        for px_, py_, rr in ((-34, -4, 6), (-44, -3, 5), (-54, -3, 4), (-62, -4, 3)):
            disco(d, x + px_, y + py_, rr, C["dra_s"])
        disco(d, x + 24, y - 8, 9, C["dra_s"])
        ret(d, x + 28, y - 9, x + 40, y - 3, C["dra_s"])
        xis(d, x + 26, y - 11, P["amarelo"])
        poli(d, [(x - 22, y - 12), (x - 12, y - 24), (x + 2, y - 12)], C["asa"])
        return
    a = p.get("asa", 150)
    S = (x - 2, y - 50)
    pts = [S]
    for da, comp in ((0, 36), (-28, 34), (-55, 28), (-82, 20)):
        dx, dy = vec(a + da)
        pts.append((S[0] + dx * comp, S[1] + dy * comp))
    poli(d, pts, C["asa"])
    for q in pts[1:]:
        lin(d, S, q, cor_s, 2)
    # cauda
    for px_, py_, rr in ((-12, -16, 7), (-22, -12, 6), (-32, -8, 5), (-42, -6, 4), (-50, -9, 3), (-56, -15, 2)):
        disco(d, x + px_, y + py_, rr, cor)
    poli(d, [(x - 56, y - 17), (x - 62, y - 24), (x - 52, y - 20)], C["bege"])
    # pernas
    ret(d, x - 13, y - 22, x - 5, y, cor_s)
    ret(d, x + 2, y - 22, x + 11, y, cor)
    for fx in (-14, 8):
        ret(d, x + fx, y - 3, x + fx + 7, y, cor_s)
        for k in (0, 2, 4):
            pt(d, x + fx + 7, y - 3 + k // 2, C["osso"])
    # corpo e barriga
    d.ellipse([x - 17, y - 50, x + 15, y - 12], fill=cor)
    d.ellipse([x + 2, y - 46, x + 15, y - 14], fill=C["bege"])
    for k in range(-44, -16, 4):
        ret(d, x + 3, y + k, x + 13, y + k, C["bege_s"])
    # pescoço
    for px_, py_, rr in ((8, -44, 8), (13, -53, 7), (18, -61, 6)):
        disco(d, x + px_, y + py_, rr, cor)
    hx, hy, b = p.get("cx", 0), p.get("cy", 0), p.get("boca", 0)
    for t in (0.2, 0.4, 0.6, 0.8):                     # pescoço até a cabeça
        disco(d, x + 18 + (24 + hx - 18) * t, y - 61 + (-67 + hy + 61) * t, 6, cor)
    ret(d, x + 21 + hx, y - 72 + hy, x + 28 + hx, y - 62 + hy, cor)
    disco(d, x + 24 + hx, y - 67 + hy, 6, cor)
    ret(d, x + 27 + hx, y - 70 + hy, x + 38 + hx, y - 64 + hy, cor)
    ret(d, x + 26 + hx, y - 63 + hy + b, x + 36 + hx, y - 60 + hy + b, cor_s)
    if b:
        ret(d, x + 27 + hx, y - 63 + hy, x + 36 + hx, y - 62 + hy + b, hexa("#4a0f12"))
    for k in (28, 31, 34):
        pt(d, x + k + hx, y - 63 + hy, C["osso"])
        pt(d, x + k + hx, y - 62 + hy + b, C["osso"])
    ret(d, x + 36 + hx, y - 69 + hy, x + 37 + hx, y - 68 + hy, P["olho"])
    ecor = P["laranja"] if furioso else P["amarelo"]
    ret(d, x + 25 + hx, y - 70 + hy, x + 27 + hx, y - 69 + hy, ecor)
    pt(d, x + 27 + hx, y - 69 + hy, P["olho"])
    lin(d, (x + 20 + hx, y - 73 + hy), (x + 12 + hx, y - 82 + hy), C["osso"], 2)
    lin(d, (x + 24 + hx, y - 74 + hy), (x + 19 + hx, y - 84 + hy), C["osso"], 2)
    # espinhos nas costas
    for k, (sx_, sy_) in enumerate(((-10, -50), (-3, -53), (4, -55))):
        poli(d, [(x + sx_, y + sy_), (x + sx_ + 2, y + sy_ - 5), (x + sx_ + 4, y + sy_)], C["osso"])


def fogo(x0, y0, comp, abre):
    def f(d, ox, oy):
        mx, my = ox + x0, oy + y0
        poli(d, [(mx, my), (mx + comp, my - abre), (mx + comp + 4, my), (mx + comp, my + abre)], P["vermelho"])
        poli(d, [(mx, my), (mx + comp * 0.85, my - abre * 0.6), (mx + comp * 0.9, my + abre * 0.6)], P["laranja"])
        poli(d, [(mx, my), (mx + comp * 0.55, my - abre * 0.3), (mx + comp * 0.55, my + abre * 0.3)], P["amarelo"])
        for k in range(6):
            pt(d, mx + comp * 0.3 + k * comp * 0.12, my - abre * 0.5 + (k * 5) % abre, P["amarelo"])
    return f


def anim_tiamat():
    idle = [frame(200, asa=145), frame(200, asa=130, dy=-1), frame(200, asa=165), frame(200, asa=150, dy=-1)]
    furioso = [dict(f, pose=dict(f["pose"], furioso=True), back=[aura(26, P["vermelho"], cy=-36)])
               for f in idle]
    return {
        "idle": idle,
        "furioso": furioso,
        "ataque": [frame(110, dx=-4, cx=-3, cy=-4, asa=120), frame(100, dx=-6, cx=-6, cy=-7, boca=4, asa=110),
                   frame(70, dx=10, cx=14, cy=6, boca=6, asa=170,
                         front=[arco(36, -52, 18, 300, 30, P["branco"], 2)]),
                   frame(80, dx=14, cx=18, cy=8, boca=3, asa=175, front=[arco(36, -52, 18, 330, 70, P["branco"], 3)]),
                   frame(120, dx=6, cx=6, cy=2, asa=150)],
        "sopro": [frame(110, dx=-2, cx=-2, cy=-3, boca=3, asa=125),
                  frame(110, dx=-3, cx=-3, cy=-5, boca=5, asa=115),
                  frame(80, dx=-2, cx=0, cy=-2, boca=7, asa=160, front=[fogo(37, -62, 18, 6)]),
                  frame(80, dx=-2, cx=0, cy=-2, boca=7, asa=140, front=[fogo(37, -62, 34, 12)]),
                  frame(80, dx=-2, cx=0, cy=-2, boca=7, asa=165, front=[fogo(37, -62, 44, 18)]),
                  frame(80, dx=-1, cx=0, cy=-1, boca=6, asa=140, front=[fogo(37, -62, 48, 20)]),
                  frame(120, dx=0, cx=0, cy=0, boca=2, asa=150)],
        "morto": [frame(200, morto=True)],
    }


MONSTROS = {
    "goblin": (goblin, anim_goblin), "morcego": (morcego, anim_morcego), "slime": (slime, anim_slime),
    "ogro": (ogro, anim_ogro), "tiamat": (tiamat, anim_tiamat),
}


def renderizar(nome, desenhar, fr):
    w, h = TAMANHOS[nome]
    cx, gy = w // 2 - (6 if nome != "tiamat" else -4), h - 4
    if nome == "tiamat":
        cx = 70
    ox, oy = cx + fr["pose"].get("dx", 0), gy
    base = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    db = ImageDraw.Draw(base)
    if nome != "morcego" or fr["pose"].get("morto"):
        db.ellipse([cx - (w // 4), gy - 1, cx + (w // 4), gy + 2], fill=(40, 40, 60, 255))
    for f in fr["back"]:
        f(db, ox, oy)
    camada = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    desenhar(ImageDraw.Draw(camada), cx, gy, fr["pose"])
    base = Image.alpha_composite(base, contorno(camada))
    df = ImageDraw.Draw(base)
    for f in fr["front"]:
        f(df, ox, oy)
    return base       # monstros ficam à esquerda e olham para a direita (para os heróis)


def main():
    os.makedirs(os.path.join(PASTA, "gif"), exist_ok=True)
    caminho_json = os.path.join(PASTA, "frames", "duracoes.json")
    duracoes = {}
    if os.path.exists(caminho_json):
        with open(caminho_json, encoding="utf-8") as f:
            duracoes = json.load(f)
    total = 0
    for nome, (desenhar, fabrica) in MONSTROS.items():
        pasta = f"monstro_{nome}"
        os.makedirs(os.path.join(PASTA, "frames", pasta), exist_ok=True)
        for anim, frames in fabrica().items():
            imgs = [renderizar(nome, desenhar, fr) for fr in frames]
            durs = [fr["dur"] for fr in frames]
            duracoes[f"{pasta}/{anim}"] = durs
            for n, im in enumerate(imgs):
                im.resize((im.width * ESC_JOGO, im.height * ESC_JOGO), Image.NEAREST).save(
                    os.path.join(PASTA, "frames", pasta, f"{anim}_{n}.png"))
            grandes = [im.resize((im.width * ESC_GIF, im.height * ESC_GIF), Image.NEAREST) for im in imgs]
            salvar_gif(grandes, durs, os.path.join(PASTA, "gif", f"{pasta}_{anim}.gif"))
            total += 1
    with open(caminho_json, "w", encoding="utf-8") as f:
        json.dump(duracoes, f, indent=1)
    print(f"{total} animações de monstros geradas.")


if __name__ == "__main__":
    main()
