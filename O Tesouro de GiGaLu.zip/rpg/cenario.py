"""
Cenários, efeitos (brasas e fogos de artifício) e baús de tesouro do RPG de turnos.

Tudo é desenhado com formas simples do tkinter (Canvas): não precisa de imagens.
O jogo_rpg.py usa este arquivo; ele precisa estar na mesma pasta.
"""
import math
import random

LARGURA, ALTURA = 1200, 300     # tamanho do palco (em pixels)
CHAO = 232                      # linha onde os personagens apoiam os pés
HORIZONTE = CHAO - 16           # onde o chão encontra o fundo do cenário

NOMES = {
    1: "Portão do Castelo",
    2: "Muralhas ao Entardecer",
    3: "Pátio do Castelo",
    4: "Castelo em Ruínas",
    5: "O Covil de Tiamat",
}


def nome_cenario(horda):
    return NOMES.get(horda, "")


# ---------------------------------------------------------------
# Ferramentas de desenho
# ---------------------------------------------------------------
def _rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def _hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def misturar(a, b, t):
    """Cor entre a e b (t de 0 a 1)."""
    ra, rb = _rgb(a), _rgb(b)
    return _hex([ra[i] + (rb[i] - ra[i]) * t for i in range(3)])


def ret(c, x0, y0, x1, y1, cor, tag="cenario", contorno=""):
    return c.create_rectangle(x0, y0, x1, y1, fill=cor, outline=contorno, tags=tag)


def oval(c, x0, y0, x1, y1, cor, tag="cenario", contorno=""):
    return c.create_oval(x0, y0, x1, y1, fill=cor, outline=contorno, tags=tag)


def poli(c, pts, cor, tag="cenario", contorno=""):
    return c.create_polygon(*[v for p in pts for v in p], fill=cor, outline=contorno, tags=tag)


def linha(c, pts, cor, larg=1, tag="cenario"):
    return c.create_line(*[v for p in pts for v in p], fill=cor, width=larg, tags=tag)


def degrade(c, y0, y1, paradas, tag="cenario"):
    """Faixa com gradiente vertical passando por várias cores (do topo à base)."""
    passos = 36
    altura = (y1 - y0) / passos
    for i in range(passos):
        t = i / (passos - 1) * (len(paradas) - 1)
        k = min(int(t), len(paradas) - 2)
        ret(c, 0, y0 + i * altura, LARGURA, y0 + (i + 1) * altura + 1, misturar(paradas[k], paradas[k + 1], t - k), tag)


def colinas(c, y_base, amp, cor, fase=0.0, freq=0.012):
    pts = [(0, CHAO)]
    for x in range(0, LARGURA + 20, 20):
        y = y_base - amp * (math.sin(x * freq + fase) * 0.6 + math.sin(x * freq * 2.3 + fase * 1.7) * 0.4 + 1) / 2
        pts.append((x, y))
    pts.append((LARGURA, CHAO))
    poli(c, pts, cor)


def nuvem(c, x, y, esc, cor):
    for dx, dy, r in ((0, 0, 16), (18, -6, 20), (40, 0, 16), (20, 6, 14)):
        oval(c, x + (dx - r) * esc, y + (dy - r * 0.6) * esc, x + (dx + r) * esc, y + (dy + r * 0.6) * esc, cor)


def estrelas(c, rng, n, y_max):
    for _ in range(n):
        x, y, t = rng.randint(0, LARGURA), rng.randint(0, y_max), rng.choice((1, 1, 2))
        ret(c, x, y, x + t, y + t, "#ffffff" if rng.random() > 0.3 else "#ffe9a0")


def pinheiro(c, x, base, alt, cor, cor_tronco="#4a2f18"):
    ret(c, x - alt * 0.05, base - alt * 0.15, x + alt * 0.05, base, cor_tronco)
    for i in range(3):
        yb = base - alt * 0.12 - i * alt * 0.26
        w = alt * (0.30 - i * 0.07)
        poli(c, [(x - w, yb), (x + w, yb), (x, yb - alt * 0.38)], cor)


def arvore_seca(c, x, base, alt, cor):
    linha(c, [(x, base), (x, base - alt)], cor, 5)
    for yf, dx, dy in ((0.45, -0.35, 0.25), (0.6, 0.4, 0.22), (0.8, -0.25, 0.2), (0.9, 0.2, 0.15)):
        y0 = base - alt * yf
        linha(c, [(x, y0), (x + dx * alt, y0 - dy * alt)], cor, 3)
        linha(c, [(x + dx * alt, y0 - dy * alt), (x + dx * alt * 1.3, y0 - dy * alt * 1.5)], cor, 2)


def tocha(c, x, base, esc=1.0):
    ret(c, x - 2 * esc, base - 40 * esc, x + 2 * esc, base, "#4a2f18")
    ret(c, x - 5 * esc, base - 44 * esc, x + 5 * esc, base - 40 * esc, "#6b6f7a")
    poli(c, [(x - 6 * esc, base - 44 * esc), (x, base - 72 * esc), (x + 6 * esc, base - 44 * esc)], "#ff8c1e")
    poli(c, [(x - 3 * esc, base - 44 * esc), (x, base - 62 * esc), (x + 3 * esc, base - 44 * esc)], "#ffe45a")


def castelo(c, cx, base, esc, parede, sombra, telhado, janela, bandeira=None, ruina=False):
    """Castelo com torres, muralha e portão. Com ruina=True aparece danificado."""
    s = esc

    def R(x0, y0, x1, y1, cor):
        ret(c, cx + x0 * s, base + y0 * s, cx + x1 * s, base + y1 * s, cor)

    def P(pts, cor):
        poli(c, [(cx + x * s, base + y * s) for x, y in pts], cor)

    def L(x0, y0, x1, y1, cor, larg=1):
        linha(c, [(cx + x0 * s, base + y0 * s), (cx + x1 * s, base + y1 * s)], cor, larg)

    # torre central (keep)
    R(-34, -112, 34, -40, parede)
    R(-34, -112, -26, -40, sombra)
    for i in range(-34, 34, 12):
        if ruina and i in (-10, 14):
            continue
        R(i, -120, i + 7, -112, parede)
    R(-15, -96, -9, -80, janela)
    R(9, -96, 15, -80, janela)
    # torres laterais
    for tx in (-72, 72):
        quebrada = ruina and tx < 0
        topo = -112 if quebrada else -140
        R(tx - 17, topo, tx + 17, 0, parede)
        R(tx - 17, topo, tx - 9, 0, sombra)
        if quebrada:
            P([(tx - 17, topo), (tx - 10, topo - 12), (tx - 3, topo - 2), (tx + 4, topo - 16),
               (tx + 10, topo - 4), (tx + 17, topo - 10), (tx + 17, topo)], parede)
        elif ruina:
            P([(tx - 23, topo), (tx - 8, -170), (tx - 2, -160), (tx + 4, -176), (tx + 23, topo)], telhado)
        else:
            P([(tx - 23, topo), (tx, -186), (tx + 23, topo)], telhado)
        R(tx - 3, -118 if not quebrada else -96, tx + 3, -104 if not quebrada else -82, janela)
    # muralha
    R(-135, -62, 135, 0, parede)
    R(-135, -62, 135, -56, sombra)
    for i in range(-135, 135, 18):
        if ruina and (i // 18) % 4 == 1:
            continue
        R(i, -72, i + 10, -62, parede)
    for y in (-48, -34, -20, -8):
        L(-135, y, 135, y, sombra)
    # portão
    R(-13, -46, 13, 0, "#120c12")
    oval(c, cx - 13 * s, base - 58 * s, cx + 13 * s, base - 34 * s, "#120c12")
    for x in (-8, -3, 3, 8):
        L(x, -52, x, 0, "#4a4a55")
    # bandeiras
    if bandeira and not ruina:
        L(0, -120, 0, -144, "#3a2a1a", 2)
        P([(0, -144), (18, -138), (0, -132)], bandeira)
        L(72, -186, 72, -206, "#3a2a1a", 2)
        P([(72, -206), (88, -201), (72, -196)], bandeira)
    if ruina:
        for pts in (((-20, -108), (-14, -96), (-22, -86), (-16, -70)), ((40, -60), (46, -44), (38, -30)),
                    ((-110, -56), (-104, -40), (-112, -26)), ((90, -58), (84, -42), (92, -28))):
            linha(c, [(cx + x * s, base + y * s) for x, y in pts], "#14151f", 2)
        for x, w in ((-150, 14), (-120, 10), (125, 12), (150, 16), (-30, 9), (30, 11)):
            P([(x - w, 0), (x - w * 0.4, -w * 0.9), (x + w * 0.5, -w * 0.7), (x + w, 0)], sombra)


def muralha(c, y_base, parede, sombra, telhado, torres):
    ret(c, 0, y_base - 70, LARGURA, y_base, parede)
    ret(c, 0, y_base - 70, LARGURA, y_base - 64, sombra)
    for x in range(0, LARGURA, 22):
        ret(c, x, y_base - 80, x + 12, y_base - 70, parede)
    for y in (-52, -36, -20):
        linha(c, [(0, y_base + y), (LARGURA, y_base + y)], sombra)
    for x in torres:
        ret(c, x - 20, y_base - 120, x + 20, y_base, parede)
        ret(c, x - 20, y_base - 120, x - 12, y_base, sombra)
        poli(c, [(x - 26, y_base - 120), (x, y_base - 160), (x + 26, y_base - 120)], telhado)


def silhueta_dragao(c, x, y, esc, cor="#120508"):
    s = esc
    oval(c, x - 14 * s, y - 6 * s, x + 14 * s, y + 6 * s, cor)
    poli(c, [(x + 12 * s, y - 3 * s), (x + 30 * s, y - 12 * s), (x + 36 * s, y - 9 * s), (x + 28 * s, y - 4 * s),
             (x + 14 * s, y + 3 * s)], cor)
    poli(c, [(x - 12 * s, y - 2 * s), (x - 40 * s, y + 8 * s), (x - 12 * s, y + 4 * s)], cor)
    poli(c, [(x - 4 * s, y - 4 * s), (x - 14 * s, y - 34 * s), (x - 30 * s, y - 46 * s), (x - 24 * s, y - 24 * s),
             (x - 36 * s, y - 30 * s), (x - 20 * s, y - 8 * s)], cor)
    poli(c, [(x + 2 * s, y - 4 * s), (x + 14 * s, y - 30 * s), (x + 30 * s, y - 40 * s), (x + 22 * s, y - 20 * s),
             (x + 34 * s, y - 22 * s), (x + 16 * s, y - 6 * s)], cor)


def estrela4(c, x, y, r, cor, tag):
    poli(c, [(x, y - r), (x + r * 0.25, y - r * 0.25), (x + r, y), (x + r * 0.25, y + r * 0.25),
             (x, y + r), (x - r * 0.25, y + r * 0.25), (x - r, y), (x - r * 0.25, y - r * 0.25)], cor, tag)


def texto_contorno(canvas, x, y, texto, fonte, cor, tags, contorno="#1c1a2b", ancora="n", espessura=1):
    """Texto com contorno escuro (legível sobre qualquer cenário). Devolve os ids criados."""
    ids = []
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
        ids.append(canvas.create_text(x + dx * espessura, y + dy * espessura, text=texto, font=fonte,
                                      fill=contorno, anchor=ancora, justify="center", tags=tags))
    ids.append(canvas.create_text(x, y, text=texto, font=fonte, fill=cor, anchor=ancora,
                                  justify="center", tags=tags))
    return ids


def chao(c, cor_topo, cor_base):
    degrade(c, HORIZONTE, ALTURA, [cor_topo, cor_base])


# ---------------------------------------------------------------
# Os 5 cenários (um por horda)
# ---------------------------------------------------------------
def _cenario_1(c, rng):
    """Portão do castelo, de manhã."""
    degrade(c, 0, HORIZONTE + 2, ["#5ab8f0", "#bfe8ff", "#fff1d0"])
    oval(c, 1000 - 48, 30 - 48, 1000 + 48, 30 + 48, "#fff6c8")
    oval(c, 1000 - 32, 30 - 32, 1000 + 32, 30 + 32, "#ffe45a")
    for x, y, e in ((150, 60, 1.2), (420, 95, 0.9), (860, 55, 1.0), (1110, 120, 0.8)):
        nuvem(c, x, y, e, "#ffffff")
    colinas(c, HORIZONTE - 30, 50, "#8ccf86", 0.5)
    colinas(c, HORIZONTE - 6, 28, "#6bb866", 2.0)
    castelo(c, 600, HORIZONTE, 1.1, "#cfc8ba", "#938c7e", "#b8453a", "#3a4a6a", bandeira="#d8382a")
    chao(c, "#58a84c", "#3a7a36")
    poli(c, [(588, HORIZONTE), (612, HORIZONTE), (730, ALTURA), (470, ALTURA)], "#c8aa78")
    for _ in range(70):
        x, y = rng.randint(0, LARGURA), rng.randint(HORIZONTE + 6, ALTURA - 4)
        linha(c, [(x, y), (x - 2, y - 5)], "#2f6a2c")
    for _ in range(14):
        x, y = rng.randint(0, LARGURA), rng.randint(HORIZONTE + 8, ALTURA - 6)
        oval(c, x, y, x + 3, y + 3, rng.choice(("#ffffff", "#ffe45a", "#ff8ab0")))
    for x in (40, 110, 1150):
        pinheiro(c, x, HORIZONTE + 8, 95, "#2f7a3a")


def _cenario_2(c, rng):
    """Muralhas ao entardecer."""
    degrade(c, 0, HORIZONTE + 2, ["#3b3a7a", "#c2507a", "#ff9a5a", "#ffd08a"])
    oval(c, 210 - 84, HORIZONTE - 20 - 84, 210 + 84, HORIZONTE - 20 + 84, "#ffb066")
    oval(c, 210 - 60, HORIZONTE - 20 - 60, 210 + 60, HORIZONTE - 20 + 60, "#ffd27a")
    nuvem(c, 700, 60, 1.4, "#e88aa0")
    nuvem(c, 980, 100, 1.0, "#f0a090")
    colinas(c, HORIZONTE - 24, 40, "#7a3f6a", 1.0)
    muralha(c, HORIZONTE, "#9a7f84", "#6e5560", "#6a2c4a", (150, 450, 750, 1050))
    castelo(c, 600, HORIZONTE, 0.95, "#a98d90", "#6e5560", "#6a2c4a", "#ffd08a", bandeira="#d8382a")
    for x in range(10, LARGURA, 64):
        pinheiro(c, x + rng.randint(-10, 10), HORIZONTE + 6, rng.randint(50, 78), "#2b2442")
    chao(c, "#4a3b52", "#2c2238")
    poli(c, [(588, HORIZONTE), (612, HORIZONTE), (740, ALTURA), (460, ALTURA)], "#7a6070")
    for _ in range(60):
        x, y = rng.randint(0, LARGURA), rng.randint(HORIZONTE + 6, ALTURA - 4)
        linha(c, [(x, y), (x - 2, y - 4)], "#5a4a66")


def _cenario_3(c, rng):
    """Pátio do castelo ao anoitecer, com tochas."""
    degrade(c, 0, HORIZONTE + 2, ["#0f1235", "#2a2060", "#6a3c8a"])
    estrelas(c, rng, 80, HORIZONTE - 70)
    oval(c, 150 - 28, 60 - 28, 150 + 28, 60 + 28, "#f4f0d0")
    oval(c, 140, 52, 148, 60, "#d8d4b0")
    oval(c, 158, 68, 166, 76, "#d8d4b0")
    colinas(c, HORIZONTE - 14, 30, "#1a1840", 0.8)
    castelo(c, 600, HORIZONTE, 1.12, "#4a4670", "#32304f", "#2a2250", "#ffd23a", bandeira="#d8382a")
    chao(c, "#4a4660", "#2a2840")
    for k in range(-6, 7):
        linha(c, [(600 + k * 12, HORIZONTE), (600 + k * 90, ALTURA)], "#38354f")
    for y in (HORIZONTE + 14, HORIZONTE + 34, HORIZONTE + 58):
        linha(c, [(0, y), (LARGURA, y)], "#38354f")
    for x in (390, 810):
        tocha(c, x, HORIZONTE + 26, 1.2)
    nuvem(c, 900, 70, 1.0, "#2a2858")


def _cenario_4(c, rng):
    """Castelo em ruínas, noite sombria."""
    degrade(c, 0, HORIZONTE + 2, ["#05060f", "#141a32", "#2a3050"])
    estrelas(c, rng, 60, HORIZONTE - 80)
    oval(c, 900 - 42, 70 - 42, 900 + 42, 70 + 42, "#e8e4cc")
    for dx, dy, r in ((-14, -10, 8), (12, 8, 10), (-6, 16, 5), (16, -16, 5)):
        oval(c, 900 + dx - r, 70 + dy - r, 900 + dx + r, 70 + dy + r, "#cfcab0")
    nuvem(c, 840, 60, 1.6, "#1c2240")
    colinas(c, HORIZONTE - 10, 42, "#10152a", 0.3)
    castelo(c, 560, HORIZONTE, 1.1, "#3a3d52", "#262840", "#1f2036", "#0c0a12", ruina=True)
    for x, h in ((90, 110), (1080, 120), (1160, 90)):
        arvore_seca(c, x, HORIZONTE + 10, h, "#0a0c16")
    chao(c, "#252a3a", "#12141f")
    for x in (230, 330, 800, 900, 1000):
        ret(c, x - 7, HORIZONTE + 2, x + 7, HORIZONTE + 16, "#4a4e60")
        oval(c, x - 7, HORIZONTE - 3, x + 7, HORIZONTE + 7, "#4a4e60")
    for _ in range(9):
        x, y = rng.randint(0, LARGURA - 200), rng.randint(HORIZONTE - 4, HORIZONTE + 30)
        oval(c, x, y, x + rng.randint(140, 240), y + 22, "#2f364e")


def _cenario_5(c, rng):
    """O covil de Tiamat: vulcão, castelo sombrio e chão de lava."""
    degrade(c, 0, HORIZONTE + 2, ["#0a0206", "#4a0c0c", "#c0300c", "#ff8a2a"])
    oval(c, 990 - 54, 64 - 54, 990 + 54, 64 + 54, "#7a1010")
    oval(c, 990 - 36, 64 - 36, 990 + 36, 64 + 36, "#d83a1a")
    silhueta_dragao(c, 760, 70, 1.0)
    silhueta_dragao(c, 470, 40, 0.6)
    h0 = HORIZONTE
    poli(c, [(900, h0), (1020, h0 - 80), (1090, h0 - 60), (1200, h0 - 110), (1200, h0)], "#1a0b0e")
    poli(c, [(0, h0), (90, h0 - 70), (150, h0 - 130), (190, h0 - 132), (220, h0 - 120), (300, h0 - 60), (380, h0)],
         "#1e0d10")
    oval(c, 152, h0 - 142, 218, h0 - 122, "#ff6a1a")
    oval(c, 168, h0 - 138, 202, h0 - 126, "#ffd23a")
    linha(c, [(170, h0 - 128), (160, h0 - 95), (172, h0 - 60), (152, h0 - 20)], "#ff5a1a", 4)
    linha(c, [(200, h0 - 126), (210, h0 - 90), (198, h0 - 56), (214, h0 - 18)], "#ff5a1a", 3)
    for dx, dy, r in ((20, -20, 14), (40, -44, 20), (74, -70, 26), (118, -100, 32)):
        oval(c, 185 + dx - r, h0 - 140 + dy - r, 185 + dx + r, h0 - 140 + dy + r, "#3a1c1c")
    castelo(c, 800, HORIZONTE, 1.1, "#241218", "#160a10", "#100608", "#ff8c1e", bandeira="#8f1b22")
    chao(c, "#3a2222", "#160c0c")
    for _ in range(11):
        x, y = rng.randint(0, LARGURA), rng.randint(HORIZONTE + 4, ALTURA - 6)
        pts = [(x, y)]
        for _ in range(4):
            x += rng.randint(14, 34)
            y += rng.randint(-6, 6)
            pts.append((x, y))
        linha(c, pts, "#ff5a1a", 3)
        linha(c, pts, "#ffd23a", 1)


_CENARIOS = {1: _cenario_1, 2: _cenario_2, 3: _cenario_3, 4: _cenario_4, 5: _cenario_5}


def desenhar_cenario(canvas, horda):
    """Desenha o cenário da horda (1 a 5) por trás de tudo no palco."""
    canvas.delete("cenario")
    rng = random.Random(horda * 97)
    _CENARIOS.get(horda, _cenario_1)(canvas, rng)
    canvas.tag_lower("cenario")


# ---------------------------------------------------------------
# Baús de tesouro (cena final)
# ---------------------------------------------------------------
def desenhar_bau(c, cx, base, cheio, esc=1.0, tag="final"):
    """Baú aberto: cheio de ouro e joias (vitória) ou vazio e empoeirado (derrota)."""
    s = esc
    CT = "#2a1608"

    def R(x0, y0, x1, y1, cor, larg=1):
        return c.create_rectangle(cx + x0 * s, base + y0 * s, cx + x1 * s, base + y1 * s,
                                  fill=cor, outline=CT, width=larg, tags=tag)

    def P(pts, cor, contorno=CT):
        return c.create_polygon(*[v for x, y in pts for v in (cx + x * s, base + y * s)],
                                fill=cor, outline=contorno, tags=tag)

    def O(x0, y0, x1, y1, cor, contorno=""):
        return c.create_oval(cx + x0 * s, base + y0 * s, cx + x1 * s, base + y1 * s,
                             fill=cor, outline=contorno, tags=tag)

    def L(pts, cor, larg=1):
        return c.create_line(*[v for x, y in pts for v in (cx + x * s, base + y * s)],
                             fill=cor, width=larg, tags=tag)

    if cheio:                                               # raios de luz dourada
        for k in range(16):
            a0 = math.radians(k * 360 / 16)
            a1 = a0 + math.radians(7)
            pts = [(0, -48), (math.cos(a0) * 105, -48 + math.sin(a0) * 105),
                   (math.cos(a1) * 105, -48 + math.sin(a1) * 105)]
            c.create_polygon(*[v for x, y in pts for v in (cx + x * s, base + y * s)],
                             fill="#ffe9a0", outline="", tags=("raios", tag))
        c.tag_raise("raios", "cenario")

    # tampa aberta (atrás)
    P([(-36, -46), (36, -46), (32, -90), (-32, -90)], "#8a5a2b" if cheio else "#4a2c14")
    R(-34, -92, 34, -86, "#e0b040" if cheio else "#8a7a50")
    L([(-12, -88), (-12, -48)], "#5a3416")
    L([(12, -88), (12, -48)], "#5a3416")
    if not cheio:                                           # teia de aranha e aranha
        L([(-32, -90), (-30, -62)], "#c8c8d0")
        L([(-32, -90), (-14, -76)], "#c8c8d0")
        L([(-32, -90), (-4, -88)], "#c8c8d0")
        L([(-30, -78), (-20, -80), (-12, -86)], "#c8c8d0")
        L([(-30, -68), (-22, -72), (-16, -78)], "#c8c8d0")
        L([(-12, -78), (-12, -64)], "#c8c8d0")
        O(-15, -64, -9, -58, "#1a1a22")
    # abertura do baú
    P([(-40, -38), (40, -38), (36, -46), (-36, -46)], "#ffd23a" if cheio else "#140a05")
    # corpo
    R(-40, -38, 40, 0, "#9a6330", 2)
    for x in (-20, 0, 20):
        L([(x, -36), (x, -2)], "#5a3416")
    R(-34, -38, -26, 0, "#6b6f7a")
    R(26, -38, 34, 0, "#6b6f7a")
    R(-42, -42, 42, -36, "#e0b040" if cheio else "#8a7a50")
    R(-7, -32, 7, -14, "#e0b040" if cheio else "#8a7a50")
    O(-2, -26, 2, -22, "#1c1a2b")
    if cheio:
        P([(-34, -40), (-24, -58), (-8, -66), (10, -64), (26, -56), (34, -40)], "#ffd23a", "#a47a1e")
        for x, y in ((-24, -48), (-10, -58), (6, -60), (20, -50), (0, -48), (-30, -43), (28, -44)):
            O(x - 5, y - 3, x + 5, y + 3, "#ffe86a", "#a47a1e")
        for x, y, cor in ((-16, -56, "#ff3a5a"), (14, -52, "#3ac8ff"), (-2, -64, "#5aff8a"), (26, -46, "#ff3a5a")):
            P([(x, y - 6), (x + 5, y), (x, y + 6), (x - 5, y)], cor, "#ffffff")
        for x, y in ((-52, -3), (-60, -9), (52, -4), (60, -10), (-46, -9)):
            O(x - 5, y - 3, x + 5, y + 3, "#ffd23a", "#a47a1e")
        for x, y, r in ((-70, -50, 7), (70, -70, 9), (-50, -88, 6), (52, -30, 6), (0, -108, 8), (-80, -20, 5)):
            estrela4(c, cx + x * s, base + y * s, r * s, "#ffffff", tag)
    else:
        for x, y in ((-18, -42), (4, -41), (20, -43), (-6, -44)):
            O(x - 3, y - 1, x + 3, y + 1, "#4a4036")
        L([(-30, -41), (-24, -44), (-16, -42)], "#6a6a74")
        O(52, -4, 60, 0, "#3a3028")
        O(-60, -3, -52, 0, "#3a3028")


# ---------------------------------------------------------------
# Efeitos animados: brasas (covil do Tiamat) e fogos de artifício
# ---------------------------------------------------------------
class Efeitos:
    CORES = ["#ff4a4a", "#ffd23a", "#4aff8a", "#4ac8ff", "#c84aff", "#ff8c1e", "#ffffff", "#ff6ad8"]

    def __init__(self, canvas):
        self.c = canvas
        self.rng = random.Random()
        self.job = None
        self.fogos = False
        self.brasas = []
        self.foguetes = []
        self.faiscas = []

    # ----- controle -----
    def _garantir_loop(self):
        if self.job is None:
            self.job = self.c.after(40, self._tick)

    def parar(self):
        if self.job is not None:
            self.c.after_cancel(self.job)
            self.job = None
        self.c.delete("efeito")
        self.fogos = False
        self.brasas.clear()
        self.foguetes.clear()
        self.faiscas.clear()

    def parar_brasas(self):
        for b in self.brasas:
            self.c.delete(b["id"])
        self.brasas.clear()

    def iniciar_brasas(self, n=45):
        for _ in range(n):
            x, y = self.rng.uniform(0, LARGURA), self.rng.uniform(40, ALTURA)
            r = self.rng.choice((1.5, 2, 2.5))
            item = self.c.create_oval(x - r, y - r, x + r, y + r, outline="", tags="efeito",
                                      fill=self.rng.choice(("#ff8c1e", "#ffd23a", "#ff5a1a")))
            self.brasas.append({"id": item, "x": x, "y": y, "r": r,
                                "vy": self.rng.uniform(0.6, 1.8), "ph": self.rng.uniform(0, 6.28)})
        self._garantir_loop()

    def iniciar_fogos(self):
        self.fogos = True
        self._lancar()
        self._lancar()
        self._garantir_loop()

    # ----- fogos de artifício -----
    def _lancar(self):
        x = self.rng.uniform(120, LARGURA - 120)
        item = self.c.create_oval(x - 2, CHAO - 2, x + 2, CHAO + 2, fill="#fff0c0", outline="", tags="efeito")
        rastro = self.c.create_line(x, CHAO, x, CHAO + 14, fill="#ffb060", width=2, tags="efeito")
        self.foguetes.append({"id": item, "rastro": rastro, "x": x, "y": float(CHAO),
                              "alvo": self.rng.uniform(40, 140), "vy": -self.rng.uniform(6, 8.5)})

    def _explodir(self, x, y):
        cor1, cor2 = self.rng.choice(self.CORES), self.rng.choice(self.CORES)
        n = self.rng.randint(40, 60)
        anel = self.rng.random() < 0.4
        for i in range(n):
            ang = 2 * math.pi * i / n if anel else self.rng.uniform(0, 2 * math.pi)
            vel = 4.4 if anel else self.rng.uniform(1.5, 5.4)
            vida = self.rng.randint(30, 46)
            item = self.c.create_oval(x - 3, y - 3, x + 3, y + 3, fill=cor1 if i % 3 else cor2,
                                      outline="", tags="efeito")
            self.faiscas.append({"id": item, "x": x, "y": y, "vx": math.cos(ang) * vel,
                                 "vy": math.sin(ang) * vel, "vida": vida, "max": vida})

    def _tick(self):
        self.job = None
        c = self.c
        for b in self.brasas:
            b["y"] -= b["vy"]
            b["ph"] += 0.08
            b["x"] += math.sin(b["ph"]) * 0.7
            if b["y"] < -4:
                b["y"], b["x"] = ALTURA + 4, self.rng.uniform(0, LARGURA)
            r = b["r"]
            c.coords(b["id"], b["x"] - r, b["y"] - r, b["x"] + r, b["y"] + r)
        if self.fogos and self.rng.random() < 0.10:
            self._lancar()
        for f in self.foguetes[:]:
            f["y"] += f["vy"]
            f["x"] += math.sin(f["y"] * 0.2) * 0.4
            c.coords(f["id"], f["x"] - 2, f["y"] - 2, f["x"] + 2, f["y"] + 2)
            c.coords(f["rastro"], f["x"], f["y"] + 3, f["x"], f["y"] + 16)
            if f["y"] <= f["alvo"]:
                self._explodir(f["x"], f["y"])
                c.delete(f["id"], f["rastro"])
                self.foguetes.remove(f)
        for s in self.faiscas[:]:
            s["vx"] *= 0.96
            s["vy"] = s["vy"] * 0.96 + 0.09
            s["x"] += s["vx"]
            s["y"] += s["vy"]
            s["vida"] -= 1
            if s["vida"] <= 0:
                c.delete(s["id"])
                self.faiscas.remove(s)
                continue
            r = 3.0 if s["vida"] > s["max"] * 0.4 else 1.8
            c.coords(s["id"], s["x"] - r, s["y"] - r, s["x"] + r, s["y"] + r)
        c.tag_raise("banner")
        if self.brasas or self.fogos or self.foguetes or self.faiscas:
            self.job = c.after(40, self._tick)
