import json
import math
import os
import random
import tkinter as tk
from tkinter import ttk, messagebox

import cenario      # cenários, fogos e tesouros (arquivo cenario.py, na mesma pasta)


# ===============================================================
# CONFIGURAÇÕES (mexa aqui para equilibrar o jogo)
# ===============================================================
TOTAL_HORDAS = 5

# Atributos base de cada classe: (hp, mp, ataque, defesa)
CLASSES = {
    "Guerreiro": (150, 0, 20, 6),
    "Mago": (90, 80, 20, 2),
    "Sacerdote": (110, 0, 9, 3),
    "Arqueiro": (105, 0, 18, 3),
}

CUSTO_MAGIA = 5
CUSTO_BOLA_FOGO = 25
MANA_POCAO = 35

RECARGA_GOLPE = 5        # Guerreiro: Golpe Devastador
RECARGA_CURA = 3         # Sacerdote: Cura (um aliado)
RECARGA_CURA_GRUPO = 4   # Sacerdote: Cura em Grupo
RECARGA_REVIVER = 6      # Sacerdote: Reviver
RECARGA_TIRO_CERTEIRO = 4   # Arqueiro: Tiro Certeiro
RECARGA_CHUVA = 5           # Arqueiro: Chuva de Flechas

CURA_FORTE = 55          # cura de um aliado
CURA_FRACA = 28          # cura de cada aliado na cura em grupo

DANO_BLOQUEADO = 0.25    # quem está bloqueando leva só 25% do dano
LIMITE_FURIA = 0.30      # Tiamat enfurece com 30% de vida ou menos


# ===============================================================
# SPRITES (gerados por gerar_sprites.py)
# ===============================================================
PASTA_FRAMES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sprites", "frames")
# Imagens suas (PNG, sem animação) que substituem os sprites gerados. Veja sprites_proprios/LEIA-ME.txt
PASTA_PROPRIOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sprites_proprios")

SEXOS = ["Masculino", "Feminino"]

# Nome da classe de acordo com o sexo escolhido
NOME_CLASSE = {
    "Guerreiro": {"Masculino": "Guerreiro", "Feminino": "Guerreira"},
    "Mago": {"Masculino": "Mago", "Feminino": "Maga"},
    "Sacerdote": {"Masculino": "Sacerdote", "Feminino": "Sacerdotisa"},
    "Arqueiro": {"Masculino": "Arqueiro", "Feminino": "Arqueira"},
}

# Qual animação toca para cada ação do jogo
ANIMACAO_DA_ACAO = {
    "atacar": "ataque", "golpe": "golpe", "provocar": "provocar", "bloquear": "defesa",
    "magia": "magia", "bola_fogo": "bola_fogo", "pocao": "pocao", "cajado": "cajado",
    "cura": "cura", "cura_grupo": "cura", "reviver": "cura", "adaga": "ataque",
    "flecha": "ataque", "tiro_duplo": "tiro_duplo", "tiro_certeiro": "tiro_certeiro", "chuva_flechas": "chuva",
}


# ===============================================================
# AÇÕES DOS PERSONAGENS
# "alvo" diz o que precisa ser escolhido: um monstro, um aliado vivo,
# um aliado caído, ou nada (None).
# ===============================================================
INFO = {
    "atacar": {
        "nome": "Atacar", "alvo": "inimigo",
        "desc": "Ataque normal contra um monstro.",
    },
    "golpe": {
        "nome": "Golpe Devastador", "alvo": "inimigo", "recarga": RECARGA_GOLPE,
        "desc": f"Muito dano em um monstro. Só pode ser usado a cada {RECARGA_GOLPE} turnos.",
    },
    "provocar": {
        "nome": "Provocar", "alvo": None,
        "desc": "Atrai o ataque dos monstros para o Guerreiro por 2 turnos.",
    },
    "bloquear": {
        "nome": "Bloquear", "alvo": None,
        "desc": "Levanta o escudo: recebe só 25% do dano até o fim da rodada.",
    },
    "magia": {
        "nome": "Magia", "alvo": "inimigo", "mp": CUSTO_MAGIA,
        "desc": "Magia simples em um monstro. Ignora a defesa. Gasta pouca mana.",
    },
    "bola_fogo": {
        "nome": "Bola de Fogo", "alvo": None, "mp": CUSTO_BOLA_FOGO,
        "desc": "Queima TODOS os monstros. Ignora a defesa. Gasta bastante mana.",
    },
    "pocao": {
        "nome": "Poção de Mana", "alvo": None,
        "desc": f"Recupera {MANA_POCAO} de mana do Mago (usa o turno).",
    },
    "cajado": {
        "nome": "Cajado", "alvo": "inimigo",
        "desc": "Pancada fraca, mas de graça. Para quando a mana acabar.",
    },
    "cura": {
        "nome": "Cura", "alvo": "aliado", "recarga": RECARGA_CURA,
        "desc": f"Cura bastante um aliado. Só a cada {RECARGA_CURA} turnos.",
    },
    "cura_grupo": {
        "nome": "Cura em Grupo", "alvo": None, "recarga": RECARGA_CURA_GRUPO,
        "desc": f"Cura pouco todos os aliados. Só a cada {RECARGA_CURA_GRUPO} turnos.",
    },
    "reviver": {
        "nome": "Reviver", "alvo": "aliado_morto", "recarga": RECARGA_REVIVER,
        "desc": "Revive um aliado caído com metade da vida. O Sacerdote perde o próximo turno.",
    },
    "adaga": {
        "nome": "Adaga", "alvo": "inimigo",
        "desc": "Ataque fraco com a adaga, para quando as curas estiverem em recarga.",
    },
    "flecha": {
        "nome": "Flecha", "alvo": "inimigo",
        "desc": "Disparo normal contra um monstro.",
    },
    "tiro_duplo": {
        "nome": "Tiro Duplo", "alvo": "inimigo",
        "desc": "Duas flechas rápidas no mesmo monstro, cada uma com dano um pouco menor.",
    },
    "tiro_certeiro": {
        "nome": "Tiro Certeiro", "alvo": "inimigo", "recarga": RECARGA_TIRO_CERTEIRO,
        "desc": f"Flecha mirada: muito dano em um monstro e ignora a defesa. Só a cada {RECARGA_TIRO_CERTEIRO} turnos.",
    },
    "chuva_flechas": {
        "nome": "Chuva de Flechas", "alvo": None, "recarga": RECARGA_CHUVA,
        "desc": f"Uma chuva de flechas atinge TODOS os monstros. Só a cada {RECARGA_CHUVA} turnos.",
    },
}

ACOES_POR_CLASSE = {
    "Guerreiro": ["atacar", "golpe", "provocar", "bloquear"],
    "Mago": ["magia", "bola_fogo", "pocao", "cajado"],
    "Sacerdote": ["cura", "cura_grupo", "reviver", "adaga"],
    "Arqueiro": ["flecha", "tiro_duplo", "tiro_certeiro", "chuva_flechas"],
}


# ===============================================================
# MONSTROS
# ===============================================================
MODELOS = {
    "Goblin": {
        "hp": 100, "ataque": 20, "defesa": 8,
        "chance_especial": 0.25, "especiais": ["golpe_sujo"],
    },
    "Morcego": {
        "hp": 85, "ataque": 10, "defesa": 5,
        "chance_especial": 0.30, "especiais": ["sugar_sangue"],
    },
    "Slime": {
        "hp": 70, "ataque": 10, "defesa": 2,
        "chance_especial": 0.50, "especiais": ["gosma"],
    },
    "Ogro": {
        "hp": 130, "ataque": 20, "defesa": 6,
        "chance_especial": 0.30, "especiais": ["esmagar"],
    },
    "Tiamat": {
        "hp": 450, "ataque": 30, "defesa": 8,
        "chance_especial": 0.35, "especiais": ["sopro_fogo", "mordida"],
        "enfurece": True,
    },
}

# Ataques especiais: "mult" multiplica o ataque, "todos" acerta a party inteira
ESPECIAIS = {
    "golpe_sujo":   {"nome": "Golpe Sujo",         "mult": 1.6, "todos": False},
    "sugar_sangue": {"nome": "Sugar Sangue",       "mult": 1.2, "todos": False, "rouba_vida": True},
    "gosma":        {"nome": "Explosão de Gosma",  "mult": 0.9, "todos": True},
    "esmagar":      {"nome": "Pancada Esmagadora", "mult": 2.0, "todos": False},
    "sopro_fogo":   {"nome": "Sopro de Fogo",      "mult": 1.3, "todos": True},
    "mordida":      {"nome": "Mordida Feroz",      "mult": 2.2, "todos": False},
}

# As 5 hordas, cada vez mais difíceis
HORDAS = [
    ["Goblin", "Goblin"],
    ["Goblin", "Morcego", "Morcego", "Slime"],
    ["Goblin", "Goblin", "Ogro", "Morcego"],
    ["Ogro", "Ogro", "Slime", "Morcego"],
    ["Tiamat"],
]


# ===============================================================
# LÓGICA DO JOGO (não usa tkinter)
# ===============================================================
def rolar(base, variacao=3):
    """Devolve o valor com um pouco de sorte (para mais ou para menos)."""
    return base + random.randint(-variacao, variacao)


class Combatente:
    """Base comum de personagens e monstros."""
    bloqueando = False

    def __init__(self, nome, hp, ataque, defesa):
        self.nome = nome
        self.hp_max = hp
        self.hp = hp
        self.ataque = ataque
        self.defesa = defesa

    def esta_vivo(self):
        return self.hp > 0

    def receber_dano(self, dano, ignora_defesa=False):
        if not ignora_defesa:
            dano -= self.defesa
        dano = max(1, dano)
        if self.bloqueando:
            dano = max(1, int(dano * DANO_BLOQUEADO))
        self.hp = max(0, self.hp - dano)
        return dano

    def curar(self, quantidade):
        """Cura até o limite de vida. Devolve quanto realmente curou."""
        if not self.esta_vivo():
            return 0
        antes = self.hp
        self.hp = min(self.hp_max, self.hp + quantidade)
        return self.hp - antes


class Personagem(Combatente):
    def __init__(self, nome, classe, hp, mp, ataque, defesa, sexo="Masculino"):
        super().__init__(nome, hp, ataque, defesa)
        self.classe = classe
        self.sexo = sexo
        self.mp_max = mp
        self.mp = mp
        self.reiniciar_combate()

    def reiniciar_combate(self):
        self.recargas = {}      # habilidade -> turnos até poder usar de novo
        self.bloqueando = False
        self.provocando = 0     # quantos turnos de monstros ainda vai atrair
        self.pula_turno = False

    def passar_rodada(self):
        """Chamado no fim de cada rodada."""
        for habilidade in self.recargas:
            if self.recargas[habilidade] > 0:
                self.recargas[habilidade] -= 1
        if self.provocando > 0:
            self.provocando -= 1
        self.bloqueando = False


class Monstro(Combatente):
    def __init__(self, nome, tipo, modelo):
        super().__init__(nome, modelo["hp"], modelo["ataque"], modelo["defesa"])
        self.tipo = tipo
        self.chance_especial = modelo["chance_especial"]
        self.especiais = modelo["especiais"]
        self.enfurece = modelo.get("enfurece", False)
        self.furioso = False

    def checar_furia(self):
        """Com pouca vida o boss fica mais forte. Devolve True na hora que enfurece."""
        if (self.enfurece and not self.furioso and self.esta_vivo()
                and self.hp <= self.hp_max * LIMITE_FURIA):
            self.furioso = True
            self.ataque = int(self.ataque * 1.5)
            self.chance_especial += 0.20
            return True
        return False


def criar_personagem(nome, classe, sexo="Masculino"):
    hp, mp, ataque, defesa = CLASSES[classe]
    return Personagem(nome, classe, hp, mp, ataque, defesa, sexo)


def rotulo_classe(p):
    """Guerreiro/Guerreira, Mago/Maga, Sacerdote/Sacerdotisa."""
    return NOME_CLASSE[p.classe][p.sexo]


def criar_horda(numero):
    """Cria os monstros da horda (1 a 5). Repetidos ganham letras: Goblin A, Goblin B."""
    tipos = HORDAS[numero - 1]
    monstros = []
    for tipo in tipos:
        if tipos.count(tipo) > 1:
            letra = chr(ord("A") + sum(1 for m in monstros if m.tipo == tipo))
            nome = f"{tipo} {letra}"
        else:
            nome = tipo
        monstros.append(Monstro(nome, tipo, MODELOS[tipo]))
    return monstros


class Batalha:
    def __init__(self, party, log):
        self.party = party
        self.log = log              # função que recebe um texto e mostra no log
        self.horda = 0
        self.rodada = 1
        self.monstros = []
        self.pocoes = 3
        self.indice = 0             # posição de quem está agindo na party
        self.estado = "jogando"     # jogando / horda_vencida / vitoria / derrota
        self.eventos = []           # (monstro, animação) para a interface tocar

    # ---------- consultas ----------
    def aliados_vivos(self):
        return [p for p in self.party if p.esta_vivo()]

    def monstros_vivos(self):
        return [m for m in self.monstros if m.esta_vivo()]

    def ator_atual(self):
        return self.party[self.indice]

    # ---------- controle das hordas ----------
    def iniciar_horda(self):
        self.horda += 1
        self.rodada = 1
        self.monstros = criar_horda(self.horda)
        for p in self.party:
            p.reiniciar_combate()
        self.estado = "jogando"
        self.log(f"===== HORDA {self.horda}/{TOTAL_HORDAS} =====")
        nomes = ", ".join(m.nome for m in self.monstros)
        if self.horda == TOTAL_HORDAS:
            self.log("Um rugido sacode a terra... Tiamat, o dragão, surge diante da party!")
        else:
            self.log(f"Apareceram: {nomes}.")
        self.log(f"--- Rodada {self.rodada} ---")
        self.indice = -1
        self.proximo()

    def _horda_vencida(self):
        self.log(f"*** Horda {self.horda} derrotada! ***")
        if self.horda >= TOTAL_HORDAS:
            self.estado = "vitoria"
            return
        self.estado = "horda_vencida"
        for p in self.party:
            if p.esta_vivo():
                p.curar(int(p.hp_max * 0.30))
            else:
                p.hp = int(p.hp_max * 0.25)
                self.log(f"{p.nome} se levanta com as forças renovadas pela vitória.")
            if p.mp_max:
                p.mp = min(p.mp_max, p.mp + int(p.mp_max * 0.40))
            p.reiniciar_combate()
        self.pocoes += 1
        self.log("A party descansa: recupera 30% da vida, parte da mana e ganha +1 Poção de Mana.")

    # ---------- turnos ----------
    def proximo(self):
        """Passa a vez. Quando todos agiram, os monstros jogam e começa nova rodada."""
        if self.estado != "jogando":
            return
        if not self.monstros_vivos():
            self._horda_vencida()
            return
        self.indice += 1
        while True:
            if self.indice >= len(self.party):
                self._fase_monstros()
                if self.estado != "jogando":
                    return
                self._fim_da_rodada()
                self.indice = 0
            ator = self.party[self.indice]
            if not ator.esta_vivo():
                self.indice += 1
            elif ator.pula_turno:
                ator.pula_turno = False
                self.log(f"{ator.nome} está exausto e perde este turno.")
                self.indice += 1
            else:
                return

    def _fim_da_rodada(self):
        for p in self.party:
            p.passar_rodada()
        self.rodada += 1
        self.log(f"--- Rodada {self.rodada} ---")

    # ---------- validação e execução das ações ----------
    def rotulo(self, ator, acao):
        """Texto do botão, com custo de mana ou turnos de recarga."""
        info = INFO[acao]
        texto = info["nome"]
        if "mp" in info:
            texto += f" ({info['mp']} MP)"
        if acao == "pocao":
            texto += f" (x{self.pocoes})"
        restante = ator.recargas.get(acao, 0)
        if restante > 0:
            texto += f" (recarga {restante})"
        return texto

    def disponivel(self, ator, acao):
        """Diz se a ação pode ser usada agora (sem olhar o alvo)."""
        info = INFO[acao]
        if ator.recargas.get(acao, 0) > 0:
            return False, "Habilidade em recarga."
        if "mp" in info and ator.mp < info["mp"]:
            return False, "Mana insuficiente."
        if acao == "pocao":
            if self.pocoes <= 0:
                return False, "Você não tem mais poções de mana."
            if ator.mp >= ator.mp_max:
                return False, "A mana já está cheia."
        if acao == "reviver" and all(p.esta_vivo() for p in self.party):
            return False, "Nenhum aliado caído para reviver."
        return True, ""

    def validar(self, ator, acao, alvo):
        ok, motivo = self.disponivel(ator, acao)
        if not ok:
            return False, motivo
        tipo = INFO[acao]["alvo"]
        if tipo == "inimigo" and not (isinstance(alvo, Monstro) and alvo.esta_vivo()):
            return False, "Escolha um monstro vivo."
        if tipo == "aliado" and not (isinstance(alvo, Personagem) and alvo.esta_vivo()):
            return False, "Escolha um aliado vivo."
        if tipo == "aliado_morto" and not (isinstance(alvo, Personagem) and not alvo.esta_vivo()):
            return False, "Escolha um aliado caído."
        return True, ""

    def executar(self, ator, acao, alvo=None):
        """Executa a ação. Devolve (deu_certo, mensagem_de_erro)."""
        if self.estado != "jogando" or ator is not self.ator_atual():
            return False, "Não é a vez desse personagem."
        ok, motivo = self.validar(ator, acao, alvo)
        if not ok:
            return False, motivo
        info = INFO[acao]
        if "mp" in info:
            ator.mp -= info["mp"]
        getattr(self, "_" + acao)(ator, alvo)
        if "recarga" in info:
            ator.recargas[acao] = info["recarga"]
        return True, ""

    # ---------- dano e efeitos em comum ----------
    def _golpear(self, atacante, alvo, dano, verbo, ignora_defesa=False):
        bloqueava = alvo.bloqueando
        real = alvo.receber_dano(dano, ignora_defesa)
        extra = " (bloqueado!)" if bloqueava else ""
        self.log(f"{atacante.nome} {verbo} {alvo.nome} e causa {real} de dano.{extra}")
        self._apos_dano(alvo)
        return real

    def _apos_dano(self, alvo):
        if not alvo.esta_vivo():
            if isinstance(alvo, Personagem):
                alvo.bloqueando = False
                alvo.provocando = 0
                self.log(f"{alvo.nome} caiu em combate!")
            else:
                self.log(f"{alvo.nome} foi derrotado!")
        elif isinstance(alvo, Monstro) and alvo.checar_furia():
            self.log(f"{alvo.nome} está quase morrendo e ENFURECE! Seus ataques ficam mais fortes!")

    # ---------- ações do Guerreiro ----------
    def _atacar(self, ator, alvo):
        self._golpear(ator, alvo, rolar(ator.ataque), "ataca")

    def _golpe(self, ator, alvo):
        self.log(f"{ator.nome} reúne toda a força para o Golpe Devastador!")
        self._golpear(ator, alvo, rolar(int(ator.ataque * 2.5)), "acerta")

    def _provocar(self, ator, alvo):
        ator.provocando = 2
        self.log(f"{ator.nome} provoca os monstros! Eles vão atacá-lo pelos próximos 2 turnos.")

    def _bloquear(self, ator, alvo):
        ator.bloqueando = True
        self.log(f"{ator.nome} ergue o escudo e se prepara para bloquear.")

    # ---------- ações do Mago ----------
    def _magia(self, ator, alvo):
        self._golpear(ator, alvo, rolar(int(ator.ataque * 1.2)), "lança uma magia em", ignora_defesa=True)

    def _bola_fogo(self, ator, alvo):
        self.log(f"{ator.nome} conjura uma Bola de Fogo!")
        for m in self.monstros_vivos():
            self._golpear(ator, m, rolar(int(ator.ataque * 1.7)), "queima", ignora_defesa=True)

    def _pocao(self, ator, alvo):
        antes = ator.mp
        ator.mp = min(ator.mp_max, ator.mp + MANA_POCAO)
        self.pocoes -= 1
        self.log(f"{ator.nome} bebe uma Poção de Mana e recupera {ator.mp - antes} de mana.")

    def _cajado(self, ator, alvo):
        self._golpear(ator, alvo, rolar(ator.ataque // 2), "golpeia com o cajado")

    # ---------- ações do Sacerdote ----------
    def _cura(self, ator, alvo):
        curado = alvo.curar(rolar(CURA_FORTE, 4))
        self.log(f"{ator.nome} cura {alvo.nome} e recupera {curado} de vida.")

    def _cura_grupo(self, ator, alvo):
        self.log(f"{ator.nome} abençoa a party com uma luz curativa!")
        for p in self.aliados_vivos():
            curado = p.curar(rolar(CURA_FRACA, 2))
            self.log(f"  {p.nome} recupera {curado} de vida.")

    def _reviver(self, ator, alvo):
        alvo.hp = alvo.hp_max // 2
        alvo.reiniciar_combate()
        ator.pula_turno = True
        self.log(f"{ator.nome} reza e traz {alvo.nome} de volta à vida com {alvo.hp} de vida!")
        self.log(f"{ator.nome} ficará exausto e perderá o próximo turno.")

    def _adaga(self, ator, alvo):
        self._golpear(ator, alvo, rolar(ator.ataque), "apunhala")

    # ---------- ações do Arqueiro ----------
    def _flecha(self, ator, alvo):
        self._golpear(ator, alvo, rolar(ator.ataque), "acerta uma flecha em")

    def _tiro_duplo(self, ator, alvo):
        self.log(f"{ator.nome} dispara duas flechas seguidas!")
        for _ in range(2):
            if alvo.esta_vivo():
                self._golpear(ator, alvo, rolar(int(ator.ataque * 0.8)), "acerta")

    def _tiro_certeiro(self, ator, alvo):
        self.log(f"{ator.nome} mira com calma para o Tiro Certeiro!")
        self._golpear(ator, alvo, rolar(int(ator.ataque * 2.3)), "atravessa", ignora_defesa=True)

    def _chuva_flechas(self, ator, alvo):
        self.log(f"{ator.nome} atira para o alto: uma Chuva de Flechas cai sobre os monstros!")
        for m in self.monstros_vivos():
            self._golpear(ator, m, rolar(int(ator.ataque * 2.5)), "fura")

    # ---------- turno dos monstros ----------
    def _fase_monstros(self):
        self.log("--- Turno dos monstros ---")
        for m in self.monstros_vivos():
            if not self.aliados_vivos():
                break
            self._turno_monstro(m)
        if not self.aliados_vivos():
            self.estado = "derrota"
            self.log("A party foi derrotada...")

    def _alvo_do_monstro(self):
        vivos = self.aliados_vivos()
        provocadores = [p for p in vivos if p.provocando > 0]
        return random.choice(provocadores or vivos)

    def _turno_monstro(self, m):
        if random.random() < m.chance_especial:
            self._usar_especial(m, random.choice(m.especiais))
        else:
            self.eventos.append((m, "ataque"))
            self._golpear(m, self._alvo_do_monstro(), rolar(m.ataque), "ataca")

    def _usar_especial(self, m, esp_id):
        esp = ESPECIAIS[esp_id]
        self.eventos.append((m, "sopro" if esp_id == "sopro_fogo" else "ataque"))
        self.log(f"{m.nome} usa {esp['nome']}!")
        alvos = self.aliados_vivos() if esp["todos"] else [self._alvo_do_monstro()]
        for alvo in alvos:
            real = self._golpear(m, alvo, rolar(int(m.ataque * esp["mult"])), "acerta")
            if esp.get("rouba_vida"):
                ganho = real // 2
                m.hp = min(m.hp_max, m.hp + ganho)
                self.log(f"{m.nome} recupera {ganho} de vida.")


# ====== INTERFACE (tkinter) ======
# ===============================================================
# Janela principal
# ===============================================================
party = []          # os 4 personagens
nomes_party = {}    # guarda os nomes digitados, para reiniciar a party
sexos_party = {}    # guarda o sexo escolhido de cada classe
animadores = []     # um animador de sprite por herói (tela de batalha)
animadores_monstros = {}   # id(monstro) -> animador
batalha = None      # será criada ao iniciar a aventura

janela = tk.Tk()
janela.title("O Tesouro de GiGaLu")
janela.geometry("1250x900")


def entrar_tela_cheia(event=None):
    janela.attributes("-fullscreen", True)


def sair_tela_cheia(event=None):
    janela.attributes("-fullscreen", False)


janela.bind("<F11>", entrar_tela_cheia)
janela.bind("<Escape>", sair_tela_cheia)

alvo_inimigo = tk.IntVar(value=0)   # índice do monstro selecionado
alvo_aliado = tk.IntVar(value=0)    # índice do aliado selecionado


# ===============================================================
# Tela de criação da party
# ===============================================================
frame_criacao = ttk.Frame(janela, padding=30)
frame_criacao.pack(expand=True)

ttk.Label(
    frame_criacao, text="Monte sua Party", font=("Arial", 22, "bold")
).grid(row=0, column=0, columnspan=3, pady=(0, 25))

entradas = {}
combos_sexo = {}
for i, classe in enumerate(CLASSES, start=1):
    ttk.Label(frame_criacao, text=f"{classe}:", font=("Arial", 14)).grid(
        row=i, column=0, sticky="e", padx=10, pady=8
    )
    entrada = ttk.Entry(frame_criacao, width=25, font=("Arial", 14))
    entrada.grid(row=i, column=1, padx=10, pady=8)
    entradas[classe] = entrada

    combo = ttk.Combobox(
        frame_criacao, values=SEXOS, state="readonly", width=12, font=("Arial", 12)
    )
    combo.set(SEXOS[0])
    combo.grid(row=i, column=2, padx=10, pady=8)
    combos_sexo[classe] = combo


def reiniciar_personagens():
    """Recria os 3 personagens com vida cheia usando os nomes já digitados."""
    party.clear()
    for classe, nome in nomes_party.items():
        party.append(criar_personagem(nome, classe, sexos_party.get(classe, "Masculino")))


def confirmar_party():
    nomes = {}
    for classe, entrada in entradas.items():
        nome = entrada.get().strip()
        if not nome:
            messagebox.showwarning("Nome faltando", f"Digite o nome do {classe}.")
            entrada.focus()
            return
        nomes[classe] = nome

    if len(set(n.lower() for n in nomes.values())) < len(nomes):
        messagebox.showwarning(
            "Nomes repetidos", "Cada personagem precisa de um nome diferente."
        )
        return

    nomes_party.clear()
    nomes_party.update(nomes)
    sexos_party.clear()
    sexos_party.update({classe: combo.get() for classe, combo in combos_sexo.items()})
    reiniciar_personagens()
    mostrar_party()


ttk.Button(
    frame_criacao, text="Confirmar Party", command=confirmar_party
).grid(row=len(CLASSES) + 1, column=0, columnspan=3, pady=25)


# ===============================================================
# Tela que mostra a party criada
# ===============================================================
frame_party = ttk.Frame(janela, padding=30)

ttk.Label(
    frame_party, text="Sua Party", font=("Arial", 22, "bold")
).pack(pady=(0, 20))

colunas = ("nome", "classe", "hp", "mp", "atk", "def")
tabela = ttk.Treeview(frame_party, columns=colunas, show="headings", height=len(CLASSES))
cabecalhos = {
    "nome": "Nome", "classe": "Classe", "hp": "HP",
    "mp": "MP", "atk": "Ataque", "def": "Defesa",
}
for col in colunas:
    tabela.heading(col, text=cabecalhos[col])
    tabela.column(col, width=110, anchor="center")
tabela.pack(pady=10)


def mostrar_party():
    frame_criacao.pack_forget()
    frame_batalha.pack_forget()
    tabela.delete(*tabela.get_children())
    for p in party:
        mp = f"{p.mp}/{p.mp_max}" if p.mp_max else "-"
        tabela.insert(
            "", "end",
            values=(p.nome, rotulo_classe(p), f"{p.hp}/{p.hp_max}", mp, p.ataque, p.defesa),
        )
    frame_party.pack(expand=True)


def editar_party():
    frame_party.pack_forget()
    frame_criacao.pack(expand=True)


botoes = ttk.Frame(frame_party)
botoes.pack(pady=20)

ttk.Button(botoes, text="Editar Party", command=editar_party).pack(
    side="left", padx=10
)
ttk.Button(
    botoes, text="Iniciar Aventura", command=lambda: iniciar_aventura()
).pack(side="left", padx=10)


# ===============================================================
# Tela de batalha
# ===============================================================
frame_batalha = ttk.Frame(janela, padding=10)

lbl_topo = ttk.Label(frame_batalha, font=("Arial", 16, "bold"))
lbl_topo.pack(pady=(0, 8))

# Palco: cenário de castelo + monstros à esquerda e heróis à direita, todos na mesma linha do chão
palco = tk.Canvas(frame_batalha, width=cenario.LARGURA, height=cenario.ALTURA,
                  highlightthickness=0, bd=0, bg="#1c1a2b")
palco.pack(pady=(0, 6))
efeitos = cenario.Efeitos(palco)              # brasas do covil e fogos de artifício

painel = ttk.Frame(frame_batalha)
painel.pack(fill="x")

frame_monstros = ttk.LabelFrame(painel, text="Monstros", padding=10)
frame_monstros.pack(side="left", fill="both", expand=True, padx=5)

frame_aliados = ttk.LabelFrame(painel, text="Sua Party", padding=10)
frame_aliados.pack(side="left", fill="both", expand=True, padx=5)

lbl_turno = ttk.Label(frame_batalha, font=("Arial", 14, "bold"))
lbl_turno.pack(pady=(12, 4))

frame_acoes = ttk.Frame(frame_batalha)
frame_acoes.pack()

lbl_dica = ttk.Label(frame_batalha, foreground="#555555")
lbl_dica.pack(pady=(6, 0))

lbl_aviso = ttk.Label(frame_batalha, foreground="#b00020")
lbl_aviso.pack(pady=2)

frame_log = ttk.Frame(frame_batalha)
frame_log.pack(fill="both", expand=True, pady=(6, 0))

texto_log = tk.Text(frame_log, height=8, state="disabled", wrap="word")
scroll_log = ttk.Scrollbar(frame_log, command=texto_log.yview)
texto_log.config(yscrollcommand=scroll_log.set)
scroll_log.pack(side="right", fill="y")
texto_log.pack(side="left", fill="both", expand=True)


# ---------------------------------------------------------------
# Animação dos sprites (heróis e monstros)
# ---------------------------------------------------------------
_cache_frames = {}
_duracoes = {}
ANIMACOES_REPETEM = {"idle", "furioso", "bloqueando"}    # as outras tocam uma vez e voltam ao estado base
ANIMACOES_FIXAS = {"caido", "morto"}       # tocam uma vez e ficam no último frame


def carregar_animacao(pasta, anim):
    """Devolve (lista de imagens, lista de durações em ms) de uma animação."""
    chave = (pasta, anim)
    if chave not in _cache_frames:
        if not _duracoes:
            try:
                with open(os.path.join(PASTA_FRAMES, "duracoes.json"), encoding="utf-8") as f:
                    _duracoes.update(json.load(f))
            except OSError:
                _duracoes["_vazio"] = []
        durs = _duracoes.get(f"{pasta}/{anim}", [])
        imagens = []
        for n in range(len(durs)):
            caminho = os.path.join(PASTA_FRAMES, pasta, f"{anim}_{n}.png")
            try:
                imagens.append(tk.PhotoImage(file=caminho))
            except tk.TclError:
                break
        _cache_frames[chave] = (imagens, durs[:len(imagens)])
    return _cache_frames[chave]


class AnimadorSprite:
    """Sprite animado de um combatente, desenhado no palco com os pés na linha do chão."""

    def __init__(self, canvas, combatente, pasta, texto, x_pes, pes, tag):
        self.canvas = canvas
        self.c = combatente
        self.pasta = pasta
        self.base = "idle"          # animação para a qual volta depois de agir
        self.anim = None
        self.indice = 0
        self.job = None
        self.fase = 0.0             # usados na comemoração (pulinhos)
        self.altura_pulo = 14
        self.estatica = None        # imagem própria do jogador, se existir
        caminho = os.path.join(PASTA_PROPRIOS, f"{pasta}.png")
        if os.path.exists(caminho):
            try:
                self.estatica = tk.PhotoImage(file=caminho)
            except tk.TclError:
                self.estatica = None
        imagens, _ = carregar_animacao(pasta, "idle")
        primeira = self.estatica if self.estatica is not None else (imagens[0] if imagens else None)
        if primeira is None:
            fx = fy = 0
        elif self.estatica is not None:
            fx, fy = primeira.width() / 2, primeira.height()       # imagem própria: pés no meio da base
        else:
            fx, fy = primeira.width() * pes[0], primeira.height() * pes[1]
        self.x_pes = x_pes
        self.x0, self.y0 = x_pes - fx, cenario.CHAO - fy
        self.item = canvas.create_image(self.x0, self.y0, anchor="nw", tags=tag)
        # o nome fica sempre na mesma altura, logo abaixo da linha do chão
        self.nome = cenario.texto_contorno(canvas, x_pes, cenario.CHAO + 14, texto,
                                           ("Arial", 10, "bold"), "#ffffff", tag)
        self.tocar("idle")

    def parar(self):
        if self.job is not None:
            self.canvas.after_cancel(self.job)
            self.job = None

    def pular(self, altura):
        self.canvas.coords(self.item, self.x0, self.y0 - altura)

    def tocar(self, anim):
        self.parar()
        self.anim = anim
        self.indice = 0
        if self.estatica is not None:       # imagem própria: não anima
            self.canvas.itemconfig(self.item, image=self.estatica)
            return
        self._passo()

    def _passo(self):
        imagens, durs = carregar_animacao(self.pasta, self.anim)
        if not imagens:
            return
        self.canvas.itemconfig(self.item, image=imagens[self.indice])
        espera = durs[self.indice]
        self.indice += 1
        if self.indice >= len(imagens):
            if self.anim in ANIMACOES_FIXAS:
                return
            if self.anim not in ANIMACOES_REPETEM:
                self.anim = self.base
            self.indice = 0
        self.job = self.canvas.after(espera, self._passo)


# Onde ficam os pés em cada imagem (fração da largura e da altura), para alinhar todo mundo
# na mesma linha do chão. Valores de gerar_sprites.py (heróis) e gerar_monstros.py (monstros).
PES_HEROI = (70 / 92, 56 / 64)
PES_MONSTRO = {
    "goblin": (20 / 52, 44 / 48), "morcego": (22 / 56, 48 / 52), "slime": (20 / 52, 36 / 40),
    "ogro": (24 / 60, 58 / 62), "tiamat": (70 / 160, 84 / 88),
}
X_HEROIS = [720, 840, 960, 1080]   # posição (pés) do guerreiro, do mago, do sacerdote e do arqueiro


def posicoes_monstros(qtd):
    """Posições (x dos pés) dos monstros na metade esquerda do palco."""
    if qtd == 1:
        return [300]
    passo = 190 if qtd == 2 else 130
    return [300 + (i - (qtd - 1) / 2) * passo for i in range(qtd)]


def montar_palco():
    """Limpa o palco e cria os heróis, todos com os pés e os nomes na mesma linha."""
    parar_final()
    for a in animadores + list(animadores_monstros.values()):
        a.parar()
    animadores.clear()
    animadores_monstros.clear()
    palco.delete("all")
    for i, p in enumerate(batalha.party):
        pasta = f"{p.classe.lower()}_{p.sexo.lower()}"
        animadores.append(AnimadorSprite(
            palco, p, pasta, f"{p.nome}\n({rotulo_classe(p)})", X_HEROIS[i], PES_HEROI, "heroi"))


def montar_palco_monstros():
    """Desenha o cenário da horda atual e cria os sprites dos monstros."""
    for a in animadores_monstros.values():
        a.parar()
    animadores_monstros.clear()
    efeitos.parar()
    palco.delete("monstro")
    palco.delete("vs")
    cenario.desenhar_cenario(palco, batalha.horda)
    cenario.texto_contorno(palco, cenario.LARGURA // 2 + 10, cenario.CHAO - 90, "VS",
                           ("Arial", 26, "bold"), "#ffffff", "vs", espessura=2)
    xs = posicoes_monstros(len(batalha.monstros))
    for m, x in zip(batalha.monstros, xs):
        animadores_monstros[id(m)] = AnimadorSprite(
            palco, m, f"monstro_{m.tipo.lower()}", m.nome, x, PES_MONSTRO[m.tipo.lower()], "monstro")
    if batalha.horda == TOTAL_HORDAS:
        efeitos.iniciar_brasas()        # brasas subindo no covil do Tiamat


def marcar_turno():
    """Setinha amarela sobre o herói que está agindo."""
    palco.delete("marcador")
    if batalha.estado != "jogando":
        return
    i = batalha.indice
    if 0 <= i < len(animadores):
        x, y = animadores[i].x_pes, cenario.CHAO - 112
        palco.create_polygon(x - 10, y, x + 10, y, x, y + 16, fill="#ffd23a",
                             outline="#1c1a2b", width=2, tags="marcador")


def tocar_eventos_monstros():
    """Toca o ataque de cada monstro, um depois do outro."""
    for i, (m, anim) in enumerate(batalha.eventos):
        janela.after(i * 450, lambda m=m, anim=anim: _ataque_monstro(m, anim))
    batalha.eventos.clear()


def _ataque_monstro(m, anim):
    a = animadores_monstros.get(id(m))
    if a is not None and m.esta_vivo() and palco.winfo_exists():
        a.tocar(anim)


# ---------------------------------------------------------------
# Cena final: vitória (fogos + tesouro) ou derrota (baú vazio + monstros comemorando)
# ---------------------------------------------------------------
TEMPO_FINAL = 6500          # quanto tempo a festa dura antes dos créditos (ms)
cena_final = {"ativo": False, "t": 0, "job": None, "token": 0, "grupo": []}


def iniciar_final(vitoria):
    cena_final["ativo"] = True
    cena_final["token"] += 1
    cena_final["t"] = 0
    token = cena_final["token"]
    palco.delete("vs")
    palco.delete("marcador")
    centro = cenario.LARGURA // 2 + 10
    if vitoria:
        efeitos.parar_brasas()
        cenario.desenhar_bau(palco, centro, cenario.CHAO + 6, cheio=True, esc=1.5)
        cenario.texto_contorno(palco, cenario.LARGURA // 2, 14, "VITÓRIA!", ("Arial", 40, "bold"),
                               "#ffd23a", "banner", espessura=3)
        efeitos.iniciar_fogos()
        grupo = [a for a in animadores if a.c.esta_vivo()]          # os heróis pulam de alegria
    else:
        cenario.desenhar_bau(palco, centro, cenario.CHAO + 6, cheio=False, esc=1.5)
        cenario.texto_contorno(palco, cenario.LARGURA // 2, 14, "DERROTA...", ("Arial", 40, "bold"),
                               "#d8382a", "banner", espessura=3)
        grupo = [a for a in animadores_monstros.values() if a.c.esta_vivo()]   # os monstros comemoram
        for i, a in enumerate(grupo):
            anim = "sopro" if a.c.tipo == "Tiamat" else "ataque"
            janela.after(300 + i * 350, lambda a=a, anim=anim: _ciclo_festa(a, anim, token))
    for i, a in enumerate(grupo):
        a.fase = i * 1.1
        a.altura_pulo = 4 if getattr(a.c, "tipo", "") == "Tiamat" else 16
    cena_final["grupo"] = grupo
    _tick_final()


def _ciclo_festa(a, anim, token):
    """Os monstros vencedores repetem o ataque (ou o sopro de fogo do Tiamat) de tempos em tempos."""
    if not cena_final["ativo"] or token != cena_final["token"]:
        return
    a.tocar(anim)
    janela.after(2200, lambda: _ciclo_festa(a, anim, token))


def _tick_final():
    if not cena_final["ativo"]:
        return
    cena_final["t"] += 1
    t = cena_final["t"]
    for a in cena_final["grupo"]:
        a.pular(abs(math.sin(t * 0.2 + a.fase)) * a.altura_pulo)
    cena_final["job"] = janela.after(40, _tick_final)


def parar_final():
    cena_final["ativo"] = False
    if cena_final["job"] is not None:
        janela.after_cancel(cena_final["job"])
        cena_final["job"] = None
    cena_final["grupo"] = []
    efeitos.parar()


def sincronizar_sprites():
    """Heróis caídos ficam cinza; monstros derrotados ficam no chão; Tiamat furiosa muda."""
    for a in animadores:
        if not a.c.esta_vivo() and a.anim != "caido":
            a.tocar("caido")
        elif a.c.esta_vivo() and a.anim == "caido":
            a.tocar("idle")
        if a.c.esta_vivo():
            base = "bloqueando" if a.c.bloqueando else "idle"
            if a.base != base:
                a.base = base
                if a.anim in ("idle", "bloqueando"):
                    a.tocar(base)
    for a in animadores_monstros.values():
        m = a.c
        if not m.esta_vivo():
            if a.anim != "morto":
                a.tocar("morto")
        elif m.furioso and a.base != "furioso":
            a.base = "furioso"
            if a.anim == "idle":
                a.tocar("furioso")


def escrever_log(mensagem):
    texto_log.config(state="normal")
    texto_log.insert("end", mensagem + "\n")
    texto_log.see("end")
    texto_log.config(state="disabled")


def limpar_log():
    texto_log.config(state="normal")
    texto_log.delete("1.0", "end")
    texto_log.config(state="disabled")


def texto_status(p):
    """Linha com MP e efeitos ativos do personagem."""
    partes = []
    if p.mp_max:
        partes.append(f"MP {p.mp}/{p.mp_max}")
    if not p.esta_vivo():
        partes.append("CAÍDO")
    if p.bloqueando:
        partes.append("Bloqueando")
    if p.provocando > 0:
        partes.append(f"Provocando ({p.provocando})")
    if p.pula_turno:
        partes.append("Exausto (perde o próximo turno)")
    for acao, restante in p.recargas.items():
        if restante > 0:
            partes.append(f"{INFO[acao]['nome']}: {restante}")
    return "   ".join(partes)


def desenhar_monstros():
    for widget in frame_monstros.winfo_children():
        widget.destroy()

    # garante que o alvo selecionado seja um monstro vivo
    vivos = [i for i, m in enumerate(batalha.monstros) if m.esta_vivo()]
    if vivos and alvo_inimigo.get() not in vivos:
        alvo_inimigo.set(vivos[0])

    for i, m in enumerate(batalha.monstros):
        linha = ttk.Frame(frame_monstros)
        linha.pack(fill="x", pady=3)
        nome = m.nome
        if m.furioso:
            nome += " (FURIOSO)"
        if not m.esta_vivo():
            nome += " (derrotado)"
        ttk.Radiobutton(
            linha, text=nome, variable=alvo_inimigo, value=i, width=24,
            state="normal" if m.esta_vivo() else "disabled",
        ).pack(side="left")
        ttk.Progressbar(linha, maximum=m.hp_max, value=m.hp, length=110).pack(
            side="left", padx=6
        )
        ttk.Label(linha, text=f"{m.hp}/{m.hp_max}").pack(side="left")


def desenhar_aliados():
    for widget in frame_aliados.winfo_children():
        widget.destroy()

    atual = batalha.ator_atual() if batalha.estado == "jogando" else None
    for i, p in enumerate(batalha.party):
        bloco = ttk.Frame(frame_aliados)
        bloco.pack(fill="x", pady=3)

        linha = ttk.Frame(bloco)
        linha.pack(fill="x")
        marca = "→ " if p is atual else "    "
        ttk.Radiobutton(
            linha, text=f"{marca}{p.nome} ({rotulo_classe(p)})",
            variable=alvo_aliado, value=i, width=26,
        ).pack(side="left")
        ttk.Progressbar(linha, maximum=p.hp_max, value=p.hp, length=110).pack(
            side="left", padx=6
        )
        ttk.Label(linha, text=f"HP {p.hp}/{p.hp_max}").pack(side="left")

        ttk.Label(
            bloco, text=texto_status(p), foreground="#555555", font=("Arial", 9)
        ).pack(anchor="w", padx=22)


def desenhar_acoes():
    for widget in frame_acoes.winfo_children():
        widget.destroy()

    if batalha.estado == "jogando":
        ator = batalha.ator_atual()
        lbl_turno.config(
            text=f"Turno de {ator.nome} ({rotulo_classe(ator)}) - Rodada {batalha.rodada}"
        )
        for acao in ACOES_POR_CLASSE[ator.classe]:
            ok, _ = batalha.disponivel(ator, acao)
            botao = ttk.Button(
                frame_acoes,
                text=batalha.rotulo(ator, acao),
                width=28,
                state="normal" if ok else "disabled",
                command=lambda a=acao: clicar_acao(a),
            )
            botao.pack(side="left", padx=4)
            botao.bind("<Enter>", lambda e, a=acao: lbl_dica.config(text=INFO[a]["desc"]))
    elif batalha.estado == "horda_vencida":
        lbl_turno.config(text=f"Horda {batalha.horda} vencida!")
        ttk.Button(
            frame_acoes, text="Próxima Horda", command=proxima_horda
        ).pack(pady=4)
    else:
        lbl_turno.config(text="Fim de jogo")


def atualizar_tela():
    lbl_topo.config(
        text=f"Horda {batalha.horda}/{TOTAL_HORDAS}  -  {cenario.nome_cenario(batalha.horda)}     |     "
             f"Poções de Mana: {batalha.pocoes}"
    )
    desenhar_monstros()
    desenhar_aliados()
    desenhar_acoes()
    sincronizar_sprites()
    marcar_turno()


def obter_alvo(acao):
    """Pega o alvo selecionado na tela, conforme o tipo de ação."""
    tipo = INFO[acao]["alvo"]
    if tipo == "inimigo":
        return batalha.monstros[alvo_inimigo.get()]
    if tipo == "aliado":
        return batalha.party[alvo_aliado.get()]
    if tipo == "aliado_morto":
        escolhido = batalha.party[alvo_aliado.get()]
        if not escolhido.esta_vivo():
            return escolhido
        caidos = [p for p in batalha.party if not p.esta_vivo()]
        return caidos[0] if len(caidos) == 1 else escolhido
    return None


def clicar_acao(acao):
    lbl_aviso.config(text="")
    ator = batalha.ator_atual()
    posicao = batalha.indice
    ok, erro = batalha.executar(ator, acao, obter_alvo(acao))
    if not ok:
        lbl_aviso.config(text=erro)
        return
    if posicao < len(animadores) and ator.esta_vivo():
        animadores[posicao].tocar(ANIMACAO_DA_ACAO[acao])   # toca a animação da ação
    batalha.proximo()
    tocar_eventos_monstros()
    atualizar_tela()
    janela.update_idletasks()
    checar_fim()


def mostrar_creditos():
    """Janelinha de créditos no fim da partida (texto vem do arquivo creditos.txt)."""
    caminho = os.path.join(os.path.dirname(os.path.abspath(__file__)), "creditos.txt")
    try:
        with open(caminho, encoding="utf-8") as f:
            texto = f.read().strip()
    except OSError:
        texto = "Sprites originais em pixel art gerados com ajuda do Claude."
    messagebox.showinfo("Créditos", texto)


def checar_fim():
    """Quando a partida acaba, mostra a festa (fogos/tesouro ou monstros comemorando) e depois os créditos."""
    if batalha.estado in ("vitoria", "derrota") and not cena_final["ativo"]:
        iniciar_final(batalha.estado == "vitoria")
        janela.after(TEMPO_FINAL, finalizar_partida)


def finalizar_partida():
    mostrar_creditos()
    if batalha.estado == "vitoria":
        quer_mais = messagebox.askyesno(
            "Parabéns!",
            "Parabéns, você venceu!\n\nDeseja ir para outra aventura?",
        )
        parar_final()
        if quer_mais:
            reiniciar_personagens()
            mostrar_party()
        else:
            janela.destroy()
    elif batalha.estado == "derrota":
        de_novo = messagebox.askyesno(
            "Derrota", "Sua party foi derrotada...\n\nDeseja tentar novamente?"
        )
        parar_final()
        if de_novo:
            reiniciar_personagens()
            iniciar_aventura()
        else:
            janela.destroy()


def proxima_horda():
    lbl_aviso.config(text="")
    batalha.iniciar_horda()
    montar_palco_monstros()
    atualizar_tela()


def iniciar_aventura():
    global batalha
    frame_party.pack_forget()
    limpar_log()
    lbl_aviso.config(text="")
    lbl_dica.config(text="")
    batalha = Batalha(party, escrever_log)
    montar_palco()
    batalha.iniciar_horda()
    montar_palco_monstros()
    frame_batalha.pack(fill="both", expand=True)
    atualizar_tela()


janela.mainloop()